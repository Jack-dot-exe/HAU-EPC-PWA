import { useMemo, useState } from "react";
import RegistrationPicker from "../components/RegistrationPicker";
import TrendChart from "../components/TrendChart";
import { useRegistrations } from "../app/registrationStore";
import { useChecks } from "../app/checksStore";
import { useUsers } from "../app/usersStore";
import type { CheckType, PowerCheckRecord, PowerCheckValues } from "../domain/models";

type CheckTypeFilter = "All" | CheckType;

const DROP_ALARM_THRESHOLD_PCT = 3; // "significantly below" (tune as you like)
const AVG_WINDOW = 5;               // compare against last N previous checks

function toISODateOnly(d: Date) {
  // yyyy-mm-dd in local timezone
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function withinDateRange(iso: string, from?: string, to?: string) {
  const t = new Date(iso).getTime();
  if (from) {
    const f = new Date(from + "T00:00:00").getTime();
    if (t < f) return false;
  }
  if (to) {
    const tt = new Date(to + "T23:59:59").getTime();
    if (t > tt) return false;
  }
  return true;
}

function avg(nums: number[]) {
  if (nums.length === 0) return null;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

function formatValues(values: PowerCheckValues) {
  const order: (keyof PowerCheckValues)[] = ["OAT", "PA", "TRQ", "TOT", "ITT", "N1"];
  const entries = order
    .filter((k) => typeof values[k] === "number")
    .map((k) => `${k}: ${values[k]}`);
  return entries.join(", ");
}

function computeAlarmForRecord(
  recordsSortedDesc: PowerCheckRecord[],
  idx: number
) {
  // recordsSortedDesc are newest -> oldest
  // previous = items after idx
  const current = recordsSortedDesc[idx];
  const prev = recordsSortedDesc.slice(idx + 1);

  const lastPrev = prev[0]?.result.deltaPct ?? null;
  const prevWindow = prev.slice(0, AVG_WINDOW).map((r) => r.result.deltaPct);
  const avgPrev = avg(prevWindow);

  const cur = current.result.deltaPct;

  const belowAvg =
    avgPrev !== null && cur <= avgPrev - DROP_ALARM_THRESHOLD_PCT;

  const belowLast =
    lastPrev !== null && cur <= lastPrev - DROP_ALARM_THRESHOLD_PCT;

  const alarm = belowAvg || belowLast;

  return { alarm, avgPrev, lastPrev };
}

export default function HistoryPage() {
  // Dataset declaration from stores
  const { checks, removeCheck } = useChecks();
  const { currentUser } = useUsers();
  const isAdmin = currentUser?.role === "admin";
  
  const { registrations } = useRegistrations();

  const [registrationId, setRegistrationId] = useState(registrations[0]?.id ?? "");
  const [checkTypeFilter, setCheckTypeFilter] = useState<CheckTypeFilter>("All");
  const [fromDate, setFromDate] = useState<string>(""); // yyyy-mm-dd
  const [toDate, setToDate] = useState<string>("");

  const [selected, setSelected] = useState<PowerCheckRecord | null>(null);

  const allForRegSortedDesc = useMemo(() => {
    return checks
      .filter((c) => c.registrationId === registrationId)
      .slice()
      .sort((a, b) => b.createdAtIso.localeCompare(a.createdAtIso));
  }, [checks, registrationId]);

  const filtered = useMemo(() => {
    return allForRegSortedDesc.filter((c) => {
      if (checkTypeFilter !== "All" && c.checkType !== checkTypeFilter) return false;
      if (!withinDateRange(c.createdAtIso, fromDate || undefined, toDate || undefined)) return false;
      return true;
    });
  }, [allForRegSortedDesc, checkTypeFilter, fromDate, toDate]);

  // For chart: use the same filtered set, but the chart expects chronological sorting inside TrendChart.
  const chartRecords = filtered;

  // Alarm count (computed on the currently filtered table order)
  const alarmCount = useMemo(() => {
    let n = 0;
    for (let i = 0; i < filtered.length; i++) {
      // alarms should compare to previous readings of the same filter set?
      // We compare against history within the filtered table order (newest->oldest),
      // so it’s consistent with what the user is viewing.
      const { alarm } = computeAlarmForRecord(filtered, i);
      if (alarm) n++;
    }
    return n;
  }, [filtered]);

  // Available check types for UI (per registration based on existing records)
  const availableCheckTypes = useMemo(() => {
    const set = new Set<CheckType>();
    for (const c of allForRegSortedDesc) set.add(c.checkType);
    return Array.from(set).sort();
  }, [allForRegSortedDesc]);

  return (
    <>
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="card bg-base-100 shadow lg:col-span-2">
          <div className="card-body">
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <h2 className="card-title">Previous Checks</h2>

              <div className="w-full md:w-72">
                <RegistrationPicker
                  registrations={registrations}
                  value={registrationId}
                  onChange={setRegistrationId}
                />
              </div>
            </div>

            <div className="mt-2 grid gap-3 md:grid-cols-3">
              <label className="form-control">
                <div className="label">
                  <span className="label-text">Check Type</span>
                </div>
                <select
                  className="select select-bordered"
                  value={checkTypeFilter}
                  onChange={(e) => setCheckTypeFilter(e.target.value as CheckTypeFilter)}
                >
                  <option value="All">All</option>
                  {availableCheckTypes.map((ct) => (
                    <option key={ct} value={ct}>
                      {ct}
                    </option>
                  ))}
                </select>
              </label>

              <label className="form-control">
                <div className="label">
                  <span className="label-text">From</span>
                </div>
                <input
                  type="date"
                  className="input input-bordered"
                  value={fromDate}
                  max={toDate || undefined}
                  onChange={(e) => setFromDate(e.target.value)}
                />
              </label>

              <label className="form-control">
                <div className="label">
                  <span className="label-text">To</span>
                </div>
                <input
                  type="date"
                  className="input input-bordered"
                  value={toDate}
                  min={fromDate || undefined}
                  onChange={(e) => setToDate(e.target.value)}
                />
              </label>
            </div>

            <div className="divider" />

            {filtered.length === 0 ? (
              <div className="alert">
                <span>No checks match the selected filters.</span>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="table table-zebra">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Type</th>
                      <th className="text-right">Expected</th>
                      <th className="text-right">Actual</th>
                      <th className="text-right">Delta</th>
                      <th>Status</th>
                      <th>Alarm</th>
                      <th className="text-right">Details</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((c, idx) => {
                      const { alarm, avgPrev, lastPrev } = computeAlarmForRecord(filtered, idx);

                      return (
                        <tr key={c.id}>
                          <td>{new Date(c.createdAtIso).toLocaleString()}</td>
                          <td>{c.checkType}</td>
                          <td className="text-right font-mono">{c.result.expectedPct}%</td>
                          <td className="text-right font-mono">{c.result.actualPct}%</td>
                          <td className="text-right font-mono">{c.result.deltaPct}%</td>
                          <td>
                            <span className={`badge ${c.result.pass ? "badge-success" : "badge-error"}`}>
                              {c.result.pass ? "PASS" : "FAIL"}
                            </span>
                          </td>
                          <td>
                            {alarm ? (
                              <span
                                className="badge badge-warning"
                                title={`Delta dropped ≥ ${DROP_ALARM_THRESHOLD_PCT}% vs avg/last. Avg=${avgPrev?.toFixed(1) ?? "—"}, Last=${lastPrev?.toFixed(1) ?? "—"}`}
                              >
                                ALARM
                              </span>
                            ) : (
                              <span className="badge badge-ghost">—</span>
                            )}
                          </td>
                          <td className="text-right">
                            <button className="btn btn-xs btn-outline" onClick={() => setSelected(c)}>
                              View
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            <div className="mt-5">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Trend (Delta % over time)</h3>
                <div className="text-sm opacity-70">
                  Trend line + alarms enabled
                </div>
              </div>
              <div className="mt-2">
                <TrendChart records={chartRecords} />
              </div>
            </div>

            <div className="mt-2 text-xs opacity-70">
              History is read-only by design (audit trail). Alarm triggers when delta drops by ≥{" "}
              {DROP_ALARM_THRESHOLD_PCT}% vs the last reading or recent average.
            </div>
          </div>
        </div>

        <div className="card bg-base-100 shadow">
          <div className="card-body">
            <h2 className="card-title">Summary</h2>

            <div className="mt-2 space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span>Shown checks</span>
                <span className="font-mono">{filtered.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Alarms</span>
                <span className="font-mono">{alarmCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Last check date</span>
                <span className="font-mono">
                  {filtered[0] ? new Date(filtered[0].createdAtIso).toLocaleDateString() : "—"}
                </span>
              </div>
            </div>

            <div className="divider" />

            <button
              className="btn btn-outline btn-sm"
              onClick={() => {
                const today = new Date();
                setFromDate(toISODateOnly(new Date(today.getTime() - 1000 * 60 * 60 * 24 * 30)));
                setToDate(toISODateOnly(today));
              }}
              disabled={allForRegSortedDesc.length === 0}
            >
              Last 30 days
            </button>
          </div>
        </div>
      </div>

      {/* Read-only details modal */}
      <dialog className={`modal ${selected ? "modal-open" : ""}`}>
        <div className="modal-box">
          <h3 className="font-bold text-lg">Check Details</h3>

          {selected && (
            <div className="mt-3 space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-2">
                <div className="opacity-70">Date</div>
                <div className="font-mono">{new Date(selected.createdAtIso).toLocaleString()}</div>

                <div className="opacity-70">Type</div>
                <div className="font-mono">{selected.checkType}</div>

                <div className="opacity-70">Inputs</div>
                <div className="font-mono">{formatValues(selected.values) || "—"}</div>
              </div>

              <div className="divider" />

              <div className="grid grid-cols-2 gap-2">
                <div className="opacity-70">Expected</div>
                <div className="font-mono">{selected.result.expectedPct}%</div>

                <div className="opacity-70">Actual</div>
                <div className="font-mono">{selected.result.actualPct}%</div>

                <div className="opacity-70">Delta</div>
                <div className="font-mono">{selected.result.deltaPct}%</div>

                <div className="opacity-70">Status</div>
                <div>
                  <span className={`badge ${selected.result.pass ? "badge-success" : "badge-error"}`}>
                    {selected.result.pass ? "PASS" : "FAIL"}
                  </span>
                </div>
              </div>
            </div>
          )}

          <div className="divider" />

          <div className="modal-action">
            {isAdmin && selected && (
              <button
                className="btn btn-error"
                onClick={() => {
                  if (!confirm("Delete this history entry? This cannot be undone.")) return;
                  removeCheck(selected.id);
                  setSelected(null);
                }}
              >
                Delete entry
              </button>
            )}

            <button className="btn" onClick={() => setSelected(null)}>
              Close
            </button>
          </div>
        </div>

        {/* click outside to close */}
        <form method="dialog" className="modal-backdrop">
          <button onClick={() => setSelected(null)}>close</button>
        </form>
      </dialog>
    </>
  );
}
