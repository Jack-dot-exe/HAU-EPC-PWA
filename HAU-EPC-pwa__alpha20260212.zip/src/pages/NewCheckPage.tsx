import { useEffect, useMemo, useState } from "react";
import RegistrationPicker from "../components/RegistrationPicker";
import DynamicFields from "../components/DynamicFields";
import { useChecks } from "../app/checksStore";
import { useProfiles } from "../app/profileStore";
import { useRegistrations } from "../app/registrationStore";
import type { CheckType, PowerCheckValues, PowerCheckRecord } from "../domain/models";
import { computeForProfile } from "../calculations";

function makeId(prefix: string) {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() ?? `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now()}`);
}

function isComplete(values: PowerCheckValues, fields: { key: keyof PowerCheckValues; required?: boolean }[]) {
  return fields.every((f) => {
    if (!f.required) return true;
    const v = values[f.key];
    return typeof v === "number" && !Number.isNaN(v);
  });
}

export default function NewCheckPage() {
  const { addCheck } = useChecks();
  const { profiles } = useProfiles();
  const { registrations } = useRegistrations();

  const [registrationId, setRegistrationId] = useState(registrations[0]?.id ?? "");

  // keep selected registration valid if admin deletes it
  useEffect(() => {
    if (registrations.length === 0) {
      setRegistrationId("");
      return;
    }
    if (!registrations.some((r) => r.id === registrationId)) {
      setRegistrationId(registrations[0].id);
    }
  }, [registrations, registrationId]);

  const reg = useMemo(() => registrations.find((r) => r.id === registrationId), [registrations, registrationId]);
  const profile = useMemo(() => profiles.find((p) => p.id === reg?.profileId), [profiles, reg?.profileId]);

  const checkTypes = profile?.checkTypes ?? (["Ground"] as CheckType[]);
  const [checkType, setCheckType] = useState<CheckType>(checkTypes[0]);

  // keep checkType valid when switching registration/profile
  useEffect(() => {
    if (!checkTypes.includes(checkType)) setCheckType(checkTypes[0]);
    setComputedResult(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.id, registrationId]);

  const fields = profile?.inputSchema[checkType] ?? [];

  const [values, setValues] = useState<PowerCheckValues>({ OAT: 15, PA: 0 });
  const [computedResult, setComputedResult] = useState<PowerCheckRecord["result"] | null>(null);

  // Clear values not part of current schema to keep data clean
  useEffect(() => {
    const allowed = new Set(fields.map((f) => f.key));
    setValues((prev) => {
      const next: PowerCheckValues = {};
      for (const k of Object.keys(prev) as (keyof PowerCheckValues)[]) {
        if (allowed.has(k as any)) next[k] = prev[k];
      }
      for (const f of fields) {
        if (f.key === "OAT" && next.OAT === undefined) next.OAT = 15;
        if (f.key === "PA" && next.PA === undefined) next.PA = 5000;
      }
      return next;
    });
    setComputedResult(null);
  }, [checkType, profile?.id]);

  const setValue = (key: keyof PowerCheckValues, value: number | undefined) =>
    setValues((s) => ({ ...s, [key]: value }));

  const canCompute = !!profile && fields.length > 0 && isComplete(values, fields);

  function onCompute() {
    if (!profile || !canCompute) return;
    try {
      const res = computeForProfile(profile, checkType, values);
      setComputedResult(res);
    } catch (e) {
      console.error(e);
      alert(e instanceof Error ? e.message : "Compute failed");
      setComputedResult(null);
    }
  }

  function onSave() {
    if (!profile || !computedResult || !registrationId) return;

    const record: PowerCheckRecord = {
      id: makeId("c"),
      createdAtIso: new Date().toISOString(),
      registrationId,
      checkType,
      values,
      result: computedResult,
    };

    addCheck(record);
    setComputedResult(null);
  }

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <div className="card bg-base-100 shadow lg:col-span-2">
        <div className="card-body">
          <h2 className="card-title">New Power Check</h2>

          {registrations.length === 0 ? (
            <div className="alert alert-warning">
              <span>No registrations configured. Add one in Admin.</span>
            </div>
          ) : (
            <>
              <div className="grid gap-3 md:grid-cols-3">
                <RegistrationPicker
                  registrations={registrations}
                  value={registrationId}
                  onChange={(id) => {
                    setRegistrationId(id);
                    setComputedResult(null);
                  }}
                />

                {/* Aircraft Profile */}
                <div className="flex flex-col gap-1">
                  <label className="label-text label">
                    Aircraft Profile
                  </label>

                  <input
                    className="input input-bordered w-full"
                    value={
                      profile
                        ? `${profile.modelName} (${profile.engine})`
                        : "—"
                    }
                    readOnly
                  />
                </div>

                {/* Check Type */}
                <div className="flex flex-col gap-1">
                  <label className="label-text label">
                    Check Type
                  </label>

                  <select
                    className="select select-bordered w-full"
                    value={checkType}
                    onChange={(e) => {
                      setCheckType(e.target.value as CheckType);
                      setComputedResult(null);
                    }}
                    disabled={!profile}
                  >
                    {checkTypes.map((ct) => (
                      <option key={ct} value={ct}>
                        {ct}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="divider" />

              {!profile ? (
                <div className="alert">
                  <span>This registration has no valid profile assigned.</span>
                </div>
              ) : fields.length === 0 ? (
                <div className="alert alert-warning">
                  <span>No input schema defined for {checkType} on this profile.</span>
                </div>
              ) : (
                <DynamicFields fields={fields} values={values} setValue={setValue as any} />
              )}

              <div className="mt-4 flex flex-wrap gap-2">
                <button className="btn btn-primary" type="button" disabled={!canCompute} onClick={onCompute}>
                  Compute
                </button>
                <button className="btn btn-outline" type="button" disabled={!computedResult} onClick={onSave}>
                  Save Check
                </button>
              </div>

              {!canCompute && profile && fields.length > 0 && (
                <div className="mt-2 text-xs opacity-70">Fill all required fields (*) to compute.</div>
              )}
            </>
          )}
        </div>
      </div>

      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <h2 className="card-title">Result</h2>

          {!computedResult ? (
            <div className="alert"><span>Enter values and click Compute.</span></div>
          ) : (
            <>
              <div className="stats stats-vertical bg-base-100">
                <div className="stat">
                  <div className="stat-title">Expected</div>
                  <div className="stat-value text-2xl">{computedResult.expectedPct}%</div>
                </div>
                <div className="stat">
                  <div className="stat-title">Actual</div>
                  <div className="stat-value text-2xl">{computedResult.actualPct}%</div>
                </div>
                <div className="stat">
                  <div className="stat-title">Delta</div>
                  <div className="stat-value text-2xl">{computedResult.deltaPct}%</div>
                </div>
              </div>

              <div className={`mt-3 alert ${computedResult.pass ? "alert-success" : "alert-error"}`}>
                <span>{computedResult.pass ? "PASS (within limits)" : "FAIL (outside limits)"}</span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}