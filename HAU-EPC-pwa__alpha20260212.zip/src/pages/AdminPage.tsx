import { useMemo, useState } from "react";
import { useProfiles } from "../app/profileStore";
import { useRegistrations } from "../app/registrationStore";
import { useUsers } from "../app/usersStore";
import { useChecks } from "../app/checksStore";
import type { Role } from "../domain/models";

function makeId(prefix: string) {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() ?? `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now()}`);
}

export default function AdminPage() {
const { profiles, resetProfiles } = useProfiles();
const { registrations, addRegistration, updateRegistration, removeRegistration, resetRegistrations } = useRegistrations();
const { users, addUser, updateUser, removeUser, resetUsers, currentUserId, setCurrentUserId } = useUsers();
const { resetChecks } = useChecks();
const { setUserPassword } = useUsers();

  // Add Registration form
  const [tailNumber, setTailNumber] = useState("");
  const [profileId, setProfileId] = useState(profiles[0]?.id ?? "");

  // Add User form
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<Role>("viewer");

  const profileById = useMemo(() => new Map(profiles.map(p => [p.id, p])), [profiles]);

  return (
    <div className="grid gap-4">
      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <h2 className="card-title">Admin Panel</h2>
          <p className="opacity-70">
            Registrations ↔ profiles, users & access rights. Changes persist locally and affect New Check + History immediately.
          </p>
        </div>
      </div>

      {/* Registrations */}
      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <div className="flex items-center justify-between gap-3">
            <h3 className="font-semibold">Registrations</h3>
          </div>

          <div className="mt-3 grid gap-3 md:grid-cols-3">
            <label className="form-control">
              <div className="label"><span className="label-text">Tail number</span></div>
              <input
                className="input input-bordered"
                placeholder="e.g. D-HABC"
                value={tailNumber}
                onChange={(e) => setTailNumber(e.target.value)}
              />
            </label>

            <label className="form-control">
              <div className="label"><span className="label-text">Profile</span></div>
              <select
                className="select select-bordered"
                value={profileId}
                onChange={(e) => setProfileId(e.target.value)}
              >
                {profiles.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.modelName} ({p.engine})
                  </option>
                ))}
              </select>
            </label>

            <div className="flex items-end">
              <button
                className="btn btn-primary w-full"
                disabled={!tailNumber.trim() || !profileId}
                onClick={() => {
                  addRegistration({
                    id: makeId("r"),
                    tailNumber: tailNumber.trim().toUpperCase(),
                    profileId,
                  });
                  setTailNumber("");
                }}
              >
                Add registration
              </button>
            </div>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="table table-zebra">
              <thead>
                <tr>
                  <th>Tail</th>
                  <th>Profile</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {registrations.map((r) => {
                  const p = profileById.get(r.profileId);
                  return (
                    <tr key={r.id}>
                      <td className="font-mono">{r.tailNumber}</td>
                      <td>
                        <select
                          className="select select-bordered select-sm"
                          value={r.profileId}
                          onChange={(e) => updateRegistration(r.id, { profileId: e.target.value })}
                        >
                          {profiles.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.modelName}
                            </option>
                          ))}
                        </select>
                        <div className="text-xs opacity-70">
                          {p ? `${p.modelName} (${p.engine})` : "—"}
                        </div>
                      </td>
                      <td className="text-right">
                        <button className="btn btn-xs btn-outline" onClick={() => removeRegistration(r.id)}>
                          Delete
                        </button>
                      </td>
                    </tr>
                  );
                })}
                {registrations.length === 0 && (
                  <tr>
                    <td colSpan={3} className="opacity-70">No registrations yet.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Profiles (read-only list for now) */}
      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <h3 className="font-semibold">Aircraft Profiles</h3>
          <p className="text-sm opacity-70">
            Next step: editing profiles (check types + schema + calculation rules). For now, profiles are seeded and selectable.
          </p>

          <div className="mt-3 overflow-x-auto">
            <table className="table table-zebra">
              <thead>
                <tr>
                  <th>Model</th>
                  <th>Engine</th>
                  <th>Check types</th>
                </tr>
              </thead>
              <tbody>
                {profiles.map((p) => (
                  <tr key={p.id}>
                    <td>{p.modelName}</td>
                    <td className="text-sm opacity-80">{p.engine}</td>
                    <td className="text-sm">{p.checkTypes.join(", ")}</td>
                  </tr>
                ))}
                {profiles.length === 0 && (
                  <tr>
                    <td colSpan={3} className="opacity-70">No profiles yet.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Users */}
      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <h3 className="font-semibold">Users & Access Rights</h3>

          <div className="mt-3 grid gap-3 md:grid-cols-3">
            <label className="form-control">
              <div className="label"><span className="label-text">Email</span></div>
              <input
                className="input input-bordered"
                placeholder="user@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </label>

            <label className="form-control">
              <div className="label"><span className="label-text">Role</span></div>
              <select className="select select-bordered" value={role} onChange={(e) => setRole(e.target.value as Role)}>
                <option value="viewer">viewer</option>
                <option value="editor">editor</option>
                <option value="admin">admin</option>
              </select>
            </label>

            <div className="flex items-end">
              <button
                className="btn btn-primary w-full"
                disabled={!email.trim()}
                onClick={() => {
                  addUser({
                    id: makeId("u"),
                    email: email.trim(),
                    role,
                    isActive: true,
                  });
                  setEmail("");
                  setRole("viewer");
                }}
              >
                Add user
              </button>
            </div>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="table table-zebra">
              <thead>
                <tr>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Rights</th>
                  <th>Set Password</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id}>
                    <td>{u.email}</td>
                    <td>
                      <select
                        className="select select-bordered select-sm"
                        value={u.role}
                        onChange={(e) => updateUser(u.id, { role: e.target.value as Role })}
                      >
                        <option value="viewer">viewer</option>
                        <option value="editor">editor</option>
                        <option value="admin">admin</option>
                      </select>
                    </td>
                    <td>
                      <button
                        className={`btn btn-xs ${u.isActive ? "btn-success" : "btn-ghost"}`}
                        onClick={() => updateUser(u.id, { isActive: !u.isActive })}
                      >
                        {u.isActive ? "Active" : "Disabled"}
                      </button>
                    </td>
                    <td>
                      <button
                        className={`btn btn-xs ${currentUserId === u.id ? "btn-primary" : "btn-outline"}`}
                        onClick={() => setCurrentUserId(u.id)}
                        disabled={!u.isActive}
                      >
                        {currentUserId === u.id ? "Current" : "Set current"}
                      </button>
                    </td>
                    <td>
                      <button
                        className="btn btn-xs btn-outline"
                        onClick={async () => {
                          const pw = prompt(`Set new password for ${u.email}:`);
                          if (!pw) return;
                          await setUserPassword(u.id, pw);
                          alert("Password set.");
                        }}
                      >
                        Set password
                      </button>
                    </td>
                    <td className="text-right">
                      <button className="btn btn-xs btn-outline" onClick={() => removeUser(u.id)}>
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
                {users.length === 0 && (
                  <tr>
                    <td colSpan={4} className="opacity-70">No users yet.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-2 text-xs opacity-70">
            Next: add “current user” + role gating (hide Admin, restrict Save, etc.).
          </div>
        </div>
      </div>
      {/*DEVELOPMENT CARD*/}
      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <h3 className="font-semibold">DEVELOPMENT Data Tools</h3>
          <p className="text-sm opacity-70">
            Reset stored data back to the seeded defaults. Use this if localStorage contains older profiles/registrations.
          </p>

          <div className="mt-3 flex flex-wrap gap-2">
            <button
              className="btn btn-outline btn-sm"
              onClick={() => {
                if (confirm("Reset PROFILES back to seed data?")) resetProfiles();
              }}
            >
              Reset Profiles
            </button>

            <button
              className="btn btn-outline btn-sm"
              onClick={() => {
                if (confirm("Reset REGISTRATIONS back to seed data?")) resetRegistrations();
              }}
            >
              Reset Registrations
            </button>

            <button
              className="btn btn-outline btn-sm"
              onClick={() => {
                if (confirm("Reset USERS back to seed data?")) resetUsers();
              }}
            >
              Reset Users
            </button>

            <button
              className="btn btn-outline btn-sm"
              onClick={() => {
                if (confirm("Reset CHECKS back to seed data? (This will overwrite saved checks)")) resetChecks();
              }}
            >
              Reset Checks
            </button>
          </div>

          <div className="mt-2 text-xs opacity-70">
            Tip: after adding new seed data in code, click the corresponding reset to reload it into localStorage.
          </div>
        </div>
      </div>
    </div>
  );
}
