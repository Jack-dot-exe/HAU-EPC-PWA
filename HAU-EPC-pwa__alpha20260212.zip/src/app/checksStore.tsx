import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { PowerCheckRecord } from "../domain/models";
import { checks as seedChecks } from "../domain/mockData";

type ChecksContextValue = {
  checks: PowerCheckRecord[];
  addCheck: (record: PowerCheckRecord) => void;
  removeCheck: (id: string) => void; // remove dataset for admin only
  resetChecks: () => void;
};

const ChecksContext = createContext<ChecksContextValue | null>(null);

const STORAGE_KEY = "engine-power-checks:v1";

function safeParse(json: string | null): PowerCheckRecord[] | null {
  if (!json) return null;
  try {
    const data = JSON.parse(json);
    if (!Array.isArray(data)) return null;
    return data as PowerCheckRecord[];
  } catch {
    return null;
  }
}

export function ChecksProvider({ children }: { children: React.ReactNode }) {
  const [checks, setChecks] = useState<PowerCheckRecord[]>(() => {
    const fromStorage = safeParse(localStorage.getItem(STORAGE_KEY));
    return fromStorage ?? seedChecks; // first run uses mock seed
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(checks));
  }, [checks]);

  const value = useMemo<ChecksContextValue>(() => {
    return {
      checks,
      addCheck: (record) => setChecks((prev) => [record, ...prev]),
      removeCheck: (id) => setChecks((prev) => prev.filter((c) => c.id !== id)),
      resetChecks: () => setChecks(seedChecks),
    };
  }, [checks]);

  return <ChecksContext.Provider value={value}>{children}</ChecksContext.Provider>;
}

export function useChecks() {
  const ctx = useContext(ChecksContext);
  if (!ctx) throw new Error("useChecks must be used inside ChecksProvider");
  return ctx;
}
