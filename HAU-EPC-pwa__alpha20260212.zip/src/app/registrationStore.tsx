import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { Registration } from "../domain/models";
import { registrations as seedRegistrations } from "../domain/mockData";

type RegistrationsContextValue = {
  registrations: Registration[];
  addRegistration: (r: Registration) => void;
  updateRegistration: (id: string, patch: Partial<Registration>) => void;
  removeRegistration: (id: string) => void;
  resetRegistrations: () => void; // Reset Seed Data
};

const RegistrationsContext = createContext<RegistrationsContextValue | null>(null);
const STORAGE_KEY = "engine-power:registrations:v1";

function safeParse(json: string | null): Registration[] | null {
  if (!json) return null;
  try {
    const data = JSON.parse(json);
    return Array.isArray(data) ? (data as Registration[]) : null;
  } catch {
    return null;
  }
}

export function RegistrationsProvider({ children }: { children: React.ReactNode }) {
  const [registrations, setRegistrations] = useState<Registration[]>(() => {
    const fromStorage = safeParse(localStorage.getItem(STORAGE_KEY));
    return fromStorage ?? seedRegistrations;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(registrations));
  }, [registrations]);

  const value = useMemo<RegistrationsContextValue>(() => {
    return {
      registrations,
      addRegistration: (r) => setRegistrations((prev) => [r, ...prev]),
      updateRegistration: (id, patch) =>
        setRegistrations((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r))),
      removeRegistration: (id) => setRegistrations((prev) => prev.filter((r) => r.id !== id)),
      resetRegistrations: () => setRegistrations(seedRegistrations),
    };
  }, [registrations]);

  return (
    <RegistrationsContext.Provider value={value}>
      {children}
    </RegistrationsContext.Provider>
  );
}

export function useRegistrations() {
  const ctx = useContext(RegistrationsContext);
  if (!ctx) throw new Error("useRegistrations must be used inside RegistrationsProvider");
  return ctx;
}
