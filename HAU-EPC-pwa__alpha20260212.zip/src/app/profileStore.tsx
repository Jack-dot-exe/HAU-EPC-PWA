import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { AircraftProfile } from "../domain/models";
import { profiles as seedProfiles } from "../domain/mockData";

type ProfilesContextValue = {
  profiles: AircraftProfile[];
  addProfile: (p: AircraftProfile) => void;
  updateProfile: (id: string, patch: Partial<AircraftProfile>) => void;
  removeProfile: (id: string) => void;
   resetProfiles: () => void; // To reset Seed Data from mockdata
};

const ProfilesContext = createContext<ProfilesContextValue | null>(null);
const STORAGE_KEY = "engine-power:profiles:v1";

//!!! To delete and reset Local Storage, Run:
// localStorage.removeItem("engine-power:profiles:v1")


function safeParse(json: string | null): AircraftProfile[] | null {
  if (!json) return null;
  try {
    const data = JSON.parse(json);
    return Array.isArray(data) ? (data as AircraftProfile[]) : null;
  } catch {
    return null;
  }
}

export function ProfilesProvider({ children }: { children: React.ReactNode }) {
  const [profiles, setProfiles] = useState<AircraftProfile[]>(() => {
    const fromStorage = safeParse(localStorage.getItem(STORAGE_KEY));
    return fromStorage ?? seedProfiles;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profiles));
  }, [profiles]);

  const value = useMemo<ProfilesContextValue>(() => {
    return {
      profiles,
      addProfile: (p) => setProfiles((prev) => [p, ...prev]),
      updateProfile: (id, patch) =>
        setProfiles((prev) => prev.map((p) => (p.id === id ? { ...p, ...patch } : p))),
      removeProfile: (id) => setProfiles((prev) => prev.filter((p) => p.id !== id)),
      resetProfiles: () => setProfiles(seedProfiles),
    };
  }, [profiles]);

  return <ProfilesContext.Provider value={value}>{children}</ProfilesContext.Provider>;
}

export function useProfiles() {
  const ctx = useContext(ProfilesContext);
  if (!ctx) throw new Error("useProfiles must be used inside ProfilesProvider");
  return ctx;
}
