// =======================
// Check modes
// =======================
export type CheckType = "Ground" | "Hover" | "In-Flight";

// =======================
// Allowed input fields
// =======================
export type InputFieldKey =
  | "OAT"  // Outside Air Temperature (°C)
  | "PA"   // Pressure Altitude (ft)
  | "TRQ"  // Torque (%)
  | "TOT"  // Turbine Outlet Temperature (°C)
  | "ITT"  // Inter-Turbine Temperature (°C)
  | "N1";  // N1 (%)

// =======================
// Field definition (UI + validation metadata)
// =======================
export interface FieldDef {
  key: InputFieldKey;
  label: string;
  unit?: string;
  required?: boolean;
  step?: number;
  min?: number;
  max?: number;
}

// =======================
// Dynamic values entered by the user
// =======================
export type PowerCheckValues = Partial<Record<InputFieldKey, number>>;

// =======================
// Calculation mapping
// =======================
export type CalculationId =
  | "ec135_arrius_2b1_n1"
  | "generic_placeholder";

// =======================
// Aircraft profile
// =======================
export interface AircraftProfile {
  id: string;
  modelName: string;
  engine: string;

  // Which checks are supported by this model
  checkTypes: CheckType[];

  // Pass/fail threshold; interpretation depends on calc.
  // For EC135 N1: this is N1 percentage points.
  limits: { deltaPercentPass: number };

  // Per-check visible inputs
  inputSchema: Partial<Record<CheckType, FieldDef[]>>;

  // Which calculation implementation to use
  calculationId: CalculationId;
}

// =======================
// Registration
// =======================
export interface Registration {
  id: string;
  tailNumber: string;
  profileId: string;
}

// =======================
// Users / roles
// =======================
export type Role = "admin" | "editor" | "viewer";

export interface User {
  id: string;
  email: string;
  role: Role;
  isActive: boolean;
  // local-auth fields (PBKDF2)
  passwordSalt?: string;     // base64
  passwordHash?: string;     // base64
  passwordIterations?: number;

}

// =======================
// Power check result (generic UI fields)
// expectedPct/actualPct/deltaPct are just labels used by UI;
// for EC135 N1 they mean expectedN1/actualN1/deltaN1.
// =======================
export interface PowerCheckResult {
  expectedPct: number;
  actualPct: number;
  deltaPct: number;
  pass: boolean;
}

// =======================
// Stored power check record (audit-safe)
// =======================
export interface PowerCheckRecord {
  id: string;
  createdAtIso: string;
  registrationId: string;
  checkType: CheckType;
  values: PowerCheckValues;
  result: PowerCheckResult;
}
