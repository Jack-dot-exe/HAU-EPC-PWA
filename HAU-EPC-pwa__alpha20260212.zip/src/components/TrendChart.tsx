import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import type { PowerCheckRecord } from "../domain/models";

type ChartPoint = {
  dateLabel: string;
  ts: number;
  delta: number;
  trend?: number;
};

function toChartData(records: PowerCheckRecord[]): ChartPoint[] {
  const sorted = records
    .slice()
    .sort((a, b) => a.createdAtIso.localeCompare(b.createdAtIso));

  const base: ChartPoint[] = sorted.map((r) => ({
    dateLabel: new Date(r.createdAtIso).toLocaleDateString(),
    ts: new Date(r.createdAtIso).getTime(),
    delta: r.result.deltaPct,
  }));

  // Add linear regression trend line on index (0..n-1) to avoid time gaps issues
  const n = base.length;
  if (n < 2) return base;

  const xs = base.map((_, i) => i);
  const ys = base.map((p) => p.delta);

  const { slope, intercept } = linearRegression(xs, ys);

  return base.map((p, i) => ({
    ...p,
    trend: round1(slope * i + intercept),
  }));
}

function linearRegression(xs: number[], ys: number[]) {
  const n = xs.length;
  const meanX = xs.reduce((a, b) => a + b, 0) / n;
  const meanY = ys.reduce((a, b) => a + b, 0) / n;

  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    const dx = xs[i] - meanX;
    num += dx * (ys[i] - meanY);
    den += dx * dx;
  }

  const slope = den === 0 ? 0 : num / den;
  const intercept = meanY - slope * meanX;
  return { slope, intercept };
}

function round1(v: number) {
  return Math.round(v * 10) / 10;
}

export default function TrendChart({ records }: { records: PowerCheckRecord[] }) {
  const data = toChartData(records);

  return (
    <div className="h-72 w-full">
      <ResponsiveContainer>
        <LineChart data={data} margin={{ top: 10, right: 20, bottom: 10, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="dateLabel" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="delta" name="Delta (%)" dot={false} />
          <Line
            type="monotone"
            dataKey="trend"
            name="Trend"
            dot={false}
            strokeDasharray="6 4"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
