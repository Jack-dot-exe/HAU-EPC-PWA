import type { FieldDef, PowerCheckValues } from "../domain/models";

export default function DynamicFields(props: {
  fields: FieldDef[];
  values: PowerCheckValues;
  setValue: (key: FieldDef["key"], value: number | undefined) => void;
}) {
  return (
    <div className="grid gap-3 md:grid-cols-2">
      {props.fields.map((f) => {
        const v = props.values[f.key];

        return (
          <div key={f.key} className="flex flex-col gap-1">
            <label htmlFor={f.key} className="label-text label">
              {f.label}
              {f.unit && ` (${f.unit})`}
              {f.required && <span className="ml-1 text-red-500">*</span>}
            </label>

            <input
              id={f.key}
              type="number"
              className="input input-bordered w-full"
              inputMode="decimal"
              step={f.step ?? "any"}
              {...(f.min !== undefined ? { min: f.min } : {})}
              {...(f.max !== undefined ? { max: f.max } : {})}
              value={v ?? ""}
              onChange={(e) => {
                const raw = e.target.value;

                if (!raw) {
                  props.setValue(f.key, undefined);
                  return;
                }

                const normalized = raw.replace(",", ".");
                const num = parseFloat(normalized);

                props.setValue(f.key, Number.isFinite(num) ? num : undefined);
              }}
            />
          </div>
        );
      })}
    </div>
  );
}

