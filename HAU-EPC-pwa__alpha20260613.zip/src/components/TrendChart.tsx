import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";
import type { PowerCheckRecord } from "../domain/models";

type ChartPoint = {
  dateLabel: string;
  ts: number;

  // Primary engine series
  delta: number;
  trend?: number;

  // Secondary engine series (only if multi-engine)
  delta2?: number;
  trend2?: number;
};

function linearRegression(xs: number[], ys: number[]) {
  const n = xs.length;
  const meanX = xs.reduce((a, b) => a + b, 0) / n;
  const meanY = ys.reduce((a, b) => a + b, 0) / n;

  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    const dx = xs[i] - meanX;
    num += dx * (ys[i] - meanY);
    den += dx * dx;
  }

  const slope = den === 0 ? 0 : num / den;
  const intercept = meanY - slope * meanX;
  return { slope, intercept };
}

function round1(v: number) {
  return Math.round(v * 10) / 10;
}

function getDeltaForEngine(record: PowerCheckRecord, engineId: string): number | null {
  const anyRec: any = record as any;

  // v2 multi-engine
  if (Array.isArray(anyRec.engines) && anyRec.engines.length > 0) {
    const e = anyRec.engines.find((x: any) => String(x.engineId) === String(engineId)) ?? anyRec.engines[0];
    const d = e?.result?.deltaPct;
    return typeof d === "number" && Number.isFinite(d) ? d : null;
  }

  // v1 single-engine
  const d = anyRec.result?.deltaPct;
  return typeof d === "number" && Number.isFinite(d) ? d : null;
}

function getEngineOptions(records: PowerCheckRecord[]) {
  // Determine engine ids/labels present in data (future-proof)
  const map = new Map<string, string>(); // id -> label
  for (const r of records) {
    const anyRec: any = r as any;
    if (Array.isArray(anyRec.engines) && anyRec.engines.length > 0) {
      for (const e of anyRec.engines) {
        const id = String(e.engineId ?? "1");
        const label = String(e.engineLabel ?? `ENG ${id}`);
        if (!map.has(id)) map.set(id, label);
      }
    }
  }

  // If none found, default single engine
  const list = Array.from(map.entries()).map(([engineId, engineLabel]) => ({ engineId, engineLabel }));
  if (list.length === 0) return [{ engineId: "1", engineLabel: "ENG 1" }];

  // Sort numeric if possible
  list.sort((a, b) => {
    const an = Number(a.engineId);
    const bn = Number(b.engineId);
    if (Number.isFinite(an) && Number.isFinite(bn)) return an - bn;
    return a.engineId.localeCompare(b.engineId);
  });

  return list;
}

function toChartData(records: PowerCheckRecord[], engineId1: string, engineId2?: string): ChartPoint[] {
  const sorted = records.slice().sort((a, b) => a.createdAtIso.localeCompare(b.createdAtIso));

  const base: ChartPoint[] = sorted
    .map((r) => {
      const d1 = getDeltaForEngine(r, engineId1);
      const d2 = engineId2 ? getDeltaForEngine(r, engineId2) : null;

      // If the primary delta is missing, drop the point (keeps chart sane)
      if (d1 === null) return null;

      return {
        dateLabel: new Date(r.createdAtIso).toLocaleDateString(),
        ts: new Date(r.createdAtIso).getTime(),
        delta: d1,
        ...(d2 !== null ? { delta2: d2 } : {}),
      } as ChartPoint;
    })
    .filter(Boolean) as ChartPoint[];

  const n = base.length;
  if (n < 2) return base;

  // Trend for primary
  {
    const xs = base.map((_, i) => i);
    const ys = base.map((p) => p.delta);
    const { slope, intercept } = linearRegression(xs, ys);
    for (let i = 0; i < base.length; i++) {
      base[i].trend = round1(slope * i + intercept);
    }
  }

  // Trend for secondary (only if present and enough data)
  if (engineId2) {
    const ys2 = base.map((p) => p.delta2).filter((v): v is number => typeof v === "number");
    if (ys2.length >= 2) {
      const xs = base.map((_, i) => i);

      // Build aligned ys array with fallback (skip if missing)
      // We'll compute regression only on points that have delta2.
      const xs2: number[] = [];
      const ys2Aligned: number[] = [];
      base.forEach((p, i) => {
        if (typeof p.delta2 === "number") {
          xs2.push(i);
          ys2Aligned.push(p.delta2);
        }
      });

      if (xs2.length >= 2) {
        const { slope, intercept } = linearRegression(xs2, ys2Aligned);
        for (let i = 0; i < base.length; i++) {
          if (typeof base[i].delta2 === "number") {
            base[i].trend2 = round1(slope * i + intercept);
          }
        }
      }
    }
  }

  return base;
}

export default function TrendChart({
  records,
  engineId,
}: {
  records: PowerCheckRecord[];
  engineId?: string; // optional; defaults to first engine found
}) {
  const engineOptions = getEngineOptions(records);

  // Primary engine: use prop if provided and present, else first option
  const primary = engineOptions.find((e) => e.engineId === engineId) ?? engineOptions[0];

  // Secondary engine: if multi-engine, pick the first engine different from primary
  const secondary = engineOptions.find((e) => e.engineId !== primary.engineId);

  const data = toChartData(records, primary.engineId, secondary?.engineId);

  const isMulti = Boolean(secondary);

  return (
    <div className="h-72 w-full">
      <ResponsiveContainer>
        <LineChart data={data} margin={{ top: 10, right: 20, bottom: 10, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="dateLabel" />
          <YAxis />
          <Tooltip />
          <Legend />

          {/* Engine 1 delta */}
          <Line
            type="monotone"
            dataKey="delta"
            name={`${primary.engineLabel} Delta (%)`}
            dot={false}
            stroke="#008cff"
          />
          {/* Engine 1 trend */}
          <Line
            type="monotone"
            dataKey="trend"
            name={`${primary.engineLabel} Trend`}
            dot={false}
            stroke="#007d9c"
            strokeDasharray="6 4"
          />

          {isMulti && (
            <>
              {/* Engine 2 delta */}
              <Line
                type="monotone"
                dataKey="delta2"
                name={`${secondary!.engineLabel} Delta (%)`}
                dot={false}
                stroke="#7a0000"
              />
              {/* Engine 2 trend */}
              <Line
                type="monotone"
                dataKey="trend2"
                name={`${secondary!.engineLabel} Trend`}
                dot={false}
                stroke="#ff0000"
                strokeDasharray="6 4"
              />
            </>
          )}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
