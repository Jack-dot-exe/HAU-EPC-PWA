import { useMemo, useState } from "react";
import RegistrationPicker from "../components/RegistrationPicker";
import TrendChart from "../components/TrendChart";
import { useRegistrations } from "../app/registrationStore";
import { useChecks } from "../app/checksStore";
import { useUsers } from "../app/usersStore";
import type { CheckType, PowerCheckRecord, PowerCheckValues } from "../domain/models";
import { decimalToHHMM } from "../calculations/utils/time";

type CheckTypeFilter = "All" | CheckType;

const DROP_ALARM_THRESHOLD_PCT = 3; // "significantly below" (tune as you like)
const AVG_WINDOW = 5; // compare against last N previous checks

function toISODateOnly(d: Date) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function withinDateRange(iso: string, from?: string, to?: string) {
  const t = new Date(iso).getTime();
  if (from) {
    const f = new Date(from + "T00:00:00").getTime();
    if (t < f) return false;
  }
  if (to) {
    const tt = new Date(to + "T23:59:59").getTime();
    if (t > tt) return false;
  }
  return true;
}

function avg(nums: number[]) {
  if (nums.length === 0) return null;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

function formatValues(values: PowerCheckValues) {
  const order: (keyof PowerCheckValues)[] = ["OAT", "PA", "TRQ", "TOT", "ITT", "N1", "TTH"];
  const entries = order
    .filter((k) => typeof values[k] === "number")
    .map((k) => `${k}: ${values[k]}`);
  return entries.join(", ");
}

// --- Multi-engine helpers -------------------------------------------------

type EngineRow = {
  engineId: string;
  engineLabel: string;
  values?: PowerCheckValues;
  result?: any;
};

function getEngines(record: PowerCheckRecord): EngineRow[] {
  const anyRec: any = record as any;
  if (Array.isArray(anyRec.engines) && anyRec.engines.length > 0) {
    return anyRec.engines.map((e: any, idx: number) => ({
      engineId: String(e.engineId ?? idx + 1),
      engineLabel: String(e.engineLabel ?? `ENG ${idx + 1}`),
      values: e.values,
      result: e.result,
    }));
  }
  return [
    {
      engineId: "1",
      engineLabel: "ENG 1",
      values: (record as any).values,
      result: (record as any).result,
    },
  ];
}

// Retreive TTH hrs
function getEffectiveTotalTimeHrs(record: PowerCheckRecord): number | undefined {
  const anyRec: any = record as any;

  // 1) Preferred: record-level
  if (typeof anyRec.totalTimeHrs === "number" && Number.isFinite(anyRec.totalTimeHrs) && anyRec.totalTimeHrs >= 0) {
    return anyRec.totalTimeHrs;
  }

  // 2) Legacy v1: stored in record.values.TTH
  const v: any = anyRec.values;
  if (v && typeof v.TTH === "number" && Number.isFinite(v.TTH) && v.TTH >= 0) return v.TTH;

  // 3) v2 multi-engine: TTH may live in engine values (typically copied from shared env)
  if (Array.isArray(anyRec.engines)) {
    for (const e of anyRec.engines) {
      const ev = e?.values;
      if (ev && typeof ev.TTH === "number" && Number.isFinite(ev.TTH) && ev.TTH >= 0) return ev.TTH;
    }
  }

  // 4) Optional: if you ever added a shared/env object
  const sv: any = anyRec.sharedValues ?? anyRec.environment ?? anyRec.env;
  if (sv && typeof sv.TTH === "number" && Number.isFinite(sv.TTH) && sv.TTH >= 0) return sv.TTH;

  return undefined;
}


function formatTotalTime(record: PowerCheckRecord) {
  const t = getEffectiveTotalTimeHrs(record);
  if (t === undefined) return "—";
  return decimalToHHMM(t);
}

function getSharedValuesForDisplay(record: PowerCheckRecord): PowerCheckValues {
  const anyRec: any = record as any;
  if (anyRec.values && typeof anyRec.values === "object") {
    return anyRec.values as PowerCheckValues;
  }
  const engines = getEngines(record);
  return (engines[0]?.values ?? {}) as PowerCheckValues;
}

function getOverallPass(record: PowerCheckRecord): boolean | null {
  const anyRec: any = record as any;

  // v2 explicit overallResult
  if (anyRec.overallResult && typeof anyRec.overallResult.pass === "boolean") {
    return anyRec.overallResult.pass;
  }

  // v2 derive from engines if possible
  const engines = getEngines(record);
  if (engines.length > 0 && engines.some((e) => e?.result && typeof e.result.pass === "boolean")) {
    const passes = engines
      .map((e) => e?.result?.pass)
      .filter((x) => typeof x === "boolean") as boolean[];
    if (passes.length > 0) return passes.every(Boolean);
  }

  // v1 fallback
  if (typeof anyRec.result?.pass === "boolean") return anyRec.result.pass;

  return null;
}

function computeAlarmForRecordEngine(recordsSortedDesc: PowerCheckRecord[], idx: number, engineId: string) {
  const current = recordsSortedDesc[idx];
  const prev = recordsSortedDesc.slice(idx + 1);

  const curEng = getEngines(current).find((e) => e.engineId === engineId);
  const cur = curEng?.result?.deltaPct;

  const lastPrevEng = prev[0] ? getEngines(prev[0]).find((e) => e.engineId === engineId) : null;
  const lastPrev = lastPrevEng?.result?.deltaPct ?? null;

  const prevWindow = prev
    .slice(0, AVG_WINDOW)
    .map((r) => getEngines(r).find((e) => e.engineId === engineId)?.result?.deltaPct)
    .filter((x) => typeof x === "number") as number[];

  const avgPrev = avg(prevWindow);

  const belowAvg = avgPrev !== null && typeof cur === "number" && cur <= avgPrev - DROP_ALARM_THRESHOLD_PCT;
  const belowLast = lastPrev !== null && typeof cur === "number" && cur <= lastPrev - DROP_ALARM_THRESHOLD_PCT;

  const alarm = belowAvg || belowLast;
  return { alarm, avgPrev, lastPrev };
}

function computeAlarmForRecordAnyEngine(recordsSortedDesc: PowerCheckRecord[], idx: number) {
  const engines = getEngines(recordsSortedDesc[idx]);
  const perEngine = engines.map((e) => {
    const res = computeAlarmForRecordEngine(recordsSortedDesc, idx, e.engineId);
    return { engineLabel: e.engineLabel, ...res };
  });

  const anyAlarm = perEngine.some((x) => x.alarm);
  return { anyAlarm, perEngine };
}

// -------------------------------------------------------------------------

export default function HistoryPage() {
  const { checks, removeCheck } = useChecks();
  const { currentUser } = useUsers();
  const isAdmin = currentUser?.role === "admin";
  const { registrations } = useRegistrations();

  const [registrationId, setRegistrationId] = useState(registrations[0]?.id ?? "");
  const [checkTypeFilter, setCheckTypeFilter] = useState<CheckTypeFilter>("All");
  const [fromDate, setFromDate] = useState<string>("");
  const [toDate, setToDate] = useState<string>("");

  const [selected, setSelected] = useState<PowerCheckRecord | null>(null);

  const allForRegSortedDesc = useMemo(() => {
    return checks
      .filter((c) => c.registrationId === registrationId)
      .slice()
      .sort((a, b) => b.createdAtIso.localeCompare(a.createdAtIso));
  }, [checks, registrationId]);

  const filtered = useMemo(() => {
    return allForRegSortedDesc.filter((c) => {
      if (checkTypeFilter !== "All" && c.checkType !== checkTypeFilter) return false;
      if (!withinDateRange(c.createdAtIso, fromDate || undefined, toDate || undefined)) return false;
      return true;
    });
  }, [allForRegSortedDesc, checkTypeFilter, fromDate, toDate]);

  const chartRecords = filtered;

  // Alarm count: alarm if ANY engine alarms in that record
  const alarmCount = useMemo(() => {
    let n = 0;
    for (let i = 0; i < filtered.length; i++) {
      const { anyAlarm } = computeAlarmForRecordAnyEngine(filtered, i);
      if (anyAlarm) n++;
    }
    return n;
  }, [filtered]);

  const availableCheckTypes = useMemo(() => {
    const set = new Set<CheckType>();
    for (const c of allForRegSortedDesc) set.add(c.checkType);
    return Array.from(set).sort();
  }, [allForRegSortedDesc]);

  return (
    <>
      <div className="grid gap-4 lg:grid-cols-4">
        <div className="card bg-base-100 shadow lg:col-span-3">
          <div className="card-body">
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <h2 className="card-title">Previous Checks</h2>

              <div className="w-full md:w-72">
                <RegistrationPicker registrations={registrations} value={registrationId} onChange={setRegistrationId} />
              </div>
            </div>

            <div className="mt-2 grid gap-3 md:grid-cols-3">
              <label className="form-control">
                <div className="label">
                  <span className="label-text">Check Type</span>
                </div>
                <select
                  className="select select-bordered"
                  value={checkTypeFilter}
                  onChange={(e) => setCheckTypeFilter(e.target.value as CheckTypeFilter)}
                >
                  <option value="All">All</option>
                  {availableCheckTypes.map((ct) => (
                    <option key={ct} value={ct}>
                      {ct}
                    </option>
                  ))}
                </select>
              </label>

              <label className="form-control">
                <div className="label">
                  <span className="label-text">From</span>
                </div>
                <input
                  type="date"
                  className="input input-bordered"
                  value={fromDate}
                  max={toDate || undefined}
                  onChange={(e) => setFromDate(e.target.value)}
                />
              </label>

              <label className="form-control">
                <div className="label">
                  <span className="label-text">To</span>
                </div>
                <input
                  type="date"
                  className="input input-bordered"
                  value={toDate}
                  min={fromDate || undefined}
                  onChange={(e) => setToDate(e.target.value)}
                />
              </label>
            </div>

            <div className="divider" />

            {filtered.length === 0 ? (
              <div className="alert">
                <span>No checks match the selected filters.</span>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="table table-zebra">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Type</th>
                      <th className="text-center">TT</th>
                      <th>Results</th>
                      {/*<th>Status</th>
                      <th>Alarm</th>*/}
                      <th className="text-right">Details</th>
                    </tr>
                  </thead>

                  <tbody>
                    {filtered.map((c, idx) => {
                      const engines = getEngines(c);
                      const isMulti = engines.length > 1;

                      const overallPass = getOverallPass(c);
                      const { anyAlarm, perEngine } = computeAlarmForRecordAnyEngine(filtered, idx);

                      const alarmTitle = perEngine
                        .map((x) => {
                          const avgPrev = x.avgPrev?.toFixed(1) ?? "—";
                          const lastPrev = x.lastPrev?.toFixed(1) ?? "—";
                          return `${x.engineLabel}: Avg=${avgPrev}, Last=${lastPrev}`;
                        })
                        .join(" | ");

                      return (
                        <tr key={c.id}>
                          <td className="w-8">{new Date(c.createdAtIso).toLocaleString()}</td>
                          <td>{c.checkType}</td>
                          <td className="text-right font-mono">{formatTotalTime(c)}</td>

                          {/* Nested table cell */}
                          <td>
                            {isMulti ? (
                              <div className="overflow-hidden">
                                <div className="divide-y divide-base-300">
                                  {engines.map((e) => {
                                    const r: any = e.result;
                                    const pass = typeof r?.pass === "boolean" ? r.pass : null;

                                    return (
                                      <div key={e.engineId} className="p-1">

                                        <div className="grid grid-cols-5 gap-1">
                                          
                                          <div className="text-right text-xs place-self-center">
                                            <div className="font-mono"> {e.engineLabel} </div>
                                          </div>
                                          
                                          <div className="text-right">
                                            <div className="text-xs opacity-70">Expected</div>
                                            <div className="font-mono">{r?.expectedPct ?? "—"}%</div>
                                          </div>
                                          <div className="text-right">
                                            <div className="text-xs opacity-70">Actual</div>
                                            <div className="font-mono">{r?.actualPct ?? "—"}%</div>
                                          </div>
                                          <div className="text-right">
                                            <div className="text-xs opacity-70">Delta</div>
                                            <div className="font-mono">{r?.deltaPct ?? "—"}%</div>
                                          </div>
                                          <div className="place-self-center"> 
                                            {pass === null ? (
                                            <span className="badge badge-ghost badge-sm">—</span>
                                            ) : (
                                            <span className={`badge badge-sm ${pass ? "badge-success badge-sm" : "badge-error badge-sm"}`}>
                                              {pass ? "PASS" : "FAIL"}
                                            </span>
                                            )}
                                          </div>
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            ) : (
                              (() => {
                                const r: any = engines[0]?.result ?? (c as any).result;
                                return (
                                  <div className="grid grid-cols-4 gap-2">
                                    <div className="text-right">
                                      <div className="text-xs opacity-70">Expected </div>
                                      <div className="font-mono">{r?.expectedPct ?? "—"}%</div>
                                    </div>
                                    <div className="text-right">
                                      <div className="text-xs opacity-70">Actual</div>
                                      <div className="font-mono">{r?.actualPct ?? "—"}%</div>
                                    </div>
                                    <div className="text-right">
                                      <div className="text-xs opacity-70">Delta</div>
                                      <div className="font-mono">{r?.deltaPct ?? "—"}%</div>
                                    </div>
                                    <div className="place-self-center"> 
                                                      {overallPass === null ? (
                                                        <span className="badge badge-ghost">—</span>
                                                      ) : (
                                                        <span className={`badge ${overallPass ? "badge-success badge-sm" : "badge-error badge-sm"}`}>
                                                          {overallPass ? "PASS" : "FAIL"}
                                                        </span>
                                                      )}          </div>
                                  </div>
                                );
                              })()
                            )}
                          </td>
                          {/*
                          <td>
                            {overallPass === null ? (
                              <span className="badge badge-ghost">—</span>
                            ) : (
                              <span className={`badge ${overallPass ? "badge-success" : "badge-error"}`}>
                                {overallPass ? "PASS" : "FAIL"}
                              </span>
                            )}
                          </td> 

                          <td>
                            {anyAlarm ? (
                              <span
                                className="badge badge-warning"
                                title={`Alarm if delta drops ≥ ${DROP_ALARM_THRESHOLD_PCT}% vs avg/last. ${alarmTitle}`}
                              >
                                ALARM
                              </span>
                            ) : (
                              <span className="badge badge-ghost">—</span>
                            )}
                          </td>*/}

                          <td className="text-right">
                            <button className="btn btn-xs btn-outline" onClick={() => setSelected(c)}>
                              View
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            <div className="mt-5">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Trend (Delta % over time)</h3>
                <div className="text-sm opacity-70">Trend lines per engine (if multi-engine)</div>
              </div>
              <div className="mt-2">
                {/* TrendChart already updated to show both engines if present */}
                <TrendChart records={chartRecords as any} />
              </div>
            </div>

            <div className="mt-2 text-xs opacity-70">
              History is read-only by design (audit trail). Alarm triggers when delta drops by ≥ {DROP_ALARM_THRESHOLD_PCT}% vs
              the last reading or recent average (any engine).
            </div>
          </div>
        </div>

        <div className="card bg-base-100 shadow">
          <div className="card-body">
            <h2 className="card-title">Summary</h2>

            <div className="mt-2 space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span>Shown checks</span>
                <span className="font-mono">{filtered.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Alarms</span>
                <span className="font-mono">{alarmCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Last check date</span>
                <span className="font-mono">
                  {filtered[0] ? new Date(filtered[0].createdAtIso).toLocaleDateString() : "—"}
                </span>
              </div>
            </div>

            <div className="divider" />

            <button
              className="btn btn-outline btn-sm"
              onClick={() => {
                const today = new Date();
                setFromDate(toISODateOnly(new Date(today.getTime() - 1000 * 60 * 60 * 24 * 30)));
                setToDate(toISODateOnly(today));
              }}
              disabled={allForRegSortedDesc.length === 0}
            >
              Last 30 days
            </button>
          </div>
        </div>
      </div>

      {/* Read-only details modal */}
      <dialog className={`modal ${selected ? "modal-open" : ""}`}>
        <div className="modal-box">
          <h3 className="font-bold text-lg">Check Details</h3>

          {selected && (() => {
            const engines = getEngines(selected);
            const sharedValues = getSharedValuesForDisplay(selected);

            return (
              <div className="mt-3 space-y-3 text-sm">
                <div className="grid grid-cols-2 gap-2">
                  <div className="opacity-70">Date</div>
                  <div className="font-mono">{new Date(selected.createdAtIso).toLocaleString()}</div>

                  <div className="opacity-70">Type</div>
                  <div className="font-mono">{selected.checkType}</div>

                  <div className="opacity-70">Total Time</div>
                  <div className="font-mono">{formatTotalTime(selected)}</div>

                  <div className="opacity-70">Shared Inputs</div>
                  <div className="font-mono">{formatValues(sharedValues) || "—"}</div>
                </div>

                <div className="divider" />

                <div className="overflow-hidden rounded-lg border border-base-300">
                  <table className="table table-compact w-full">
                    <thead>
                      <tr className="bg-base-200">
                        <th>Engine</th>
                        <th className="text-right">Expected</th>
                        <th className="text-right">Actual</th>
                        <th className="text-right">Delta</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {engines.map((e) => {
                        const r: any = e.result;
                        const pass = typeof r?.pass === "boolean" ? r.pass : null;
                        return (
                          <tr key={e.engineId}>
                            <td className="font-mono">{e.engineLabel}</td>
                            <td className="text-right font-mono">{r?.expectedPct ?? "—"}%</td>
                            <td className="text-right font-mono">{r?.actualPct ?? "—"}%</td>
                            <td className="text-right font-mono">{r?.deltaPct ?? "—"}%</td>
                            <td>
                              {pass === null ? (
                                <span className="badge badge-ghost">—</span>
                              ) : (
                                <span className={`badge ${pass ? "badge-success" : "badge-error"}`}>
                                  {pass ? "PASS" : "FAIL"}
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })()}

          <div className="divider" />

          <div className="modal-action">
            {isAdmin && selected && (
              <button
                className="btn btn-error"
                onClick={() => {
                  if (!confirm("Delete this history entry? This cannot be undone.")) return;
                  removeCheck(selected.id);
                  setSelected(null);
                }}
              >
                Delete entry
              </button>
            )}

            <button className="btn" onClick={() => setSelected(null)}>
              Close
            </button>
          </div>
        </div>

        <form method="dialog" className="modal-backdrop">
          <button onClick={() => setSelected(null)}>close</button>
        </form>
      </dialog>
    </>
  );
}
