import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../app/authStore";
import { useUsers } from "../app/usersStore";

import epclogo from "../assets/epclogo.svg";
import haulogo from "../assets/HAU-logo-schwarz.svg";

function makeToken() {
  // @ts-ignore
  return globalThis.crypto?.randomUUID?.() ?? `tok_${Math.random().toString(16).slice(2)}_${Date.now()}`;
}

export default function LoginPage() {
  const nav = useNavigate();
  const { loginWithToken } = useAuth();
  const { loginWithEmailPassword, setCurrentUserId } = useUsers();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  async function onLogin() {
    setBusy(true);
    try {
      const user = await loginWithEmailPassword(email, password);
      setCurrentUserId(user.id);
      loginWithToken(makeToken()); // saved in localStorage by authStore
      nav("/", { replace: true });
    } catch (e) {
      alert(e instanceof Error ? e.message : "Login failed");
    } finally {
      setBusy(false);
    }
  }

  return (

    <div className="hero bg-base-200 min-h-screen">
              <div className="fixed bottom-15 w-40">
                <img src={haulogo} />
              </div>

        <div className="hero-content mx-25 flex-col lg:flex-row-reverse">
            <div className="grid grid-cols-1 m-5">
                <div className="justify-self-center lg:justify-self-start">
                    <img src={epclogo} className="min-h-24 "/>
                </div>
                
                <div className="text-center lg:text-left lg:w-sm">
                    <h1 className="text-5xl font-bold py-6">Login now!</h1>
                    <p className=" ">
                        A dream come true. Log-In and experience Engine Power Checks at a new level. Enter your EPCs now or stay silent forever!
                    </p>
                </div>
            </div>



            <div className="card bg-base-100 w-full max-w-sm shrink-0 shadow-2xl">
                <div className="card-body">
                    <fieldset className="fieldset">
                    <label className="label">Email</label>
                    <input type="email" 
                        className="input" 
                        autoComplete="email" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="ichbinich@heli-austria.at"
                        />
                    <label className="label">Password</label>
                        <input
                        type="password"
                        className="input input-bordered"
                        autoComplete="current-password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        onKeyDown={(e) => {
                            if (e.key === "Enter" && email.trim() && password) onLogin();
                        }}
                        />
                    <div><a className="link link-hover">Forgot password?</a></div>
                    <button className="btn btn-neutral mt-4" onClick={onLogin} disabled={!email.trim() || !password || busy}>
                        {busy ? "Logging in..." : "Log in"}
                    </button>
                    </fieldset>
                </div>
            </div>
        </div>
    </div>

/*
    /// ALT
    <div className="">
      <div className="card bg-base-100 shadow place-self-center">
        <div className="card-body">
          <h2 className="card-title">Log in</h2>

          <label className="form-control mt-2">
            <div className="label"><span className="label-text">Email</span></div>
            <input
              className="input input-bordered"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
            />
          </label>

          <label className="form-control mt-2">
            <div className="label"><span className="label-text">Password</span></div>
            <input
              type="password"
              className="input input-bordered"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              onKeyDown={(e) => {
                if (e.key === "Enter" && email.trim() && password) onLogin();
              }}
            />
          </label>

          <button className="btn btn-primary mt-4" onClick={onLogin} disabled={!email.trim() || !password || busy}>
            {busy ? "Logging in..." : "Log in"}
          </button>

          <div className="mt-2 text-xs opacity-70">
            Session token is stored locally on this device.
          </div>
        </div>
      </div>
    </div>

    */

    );
}
