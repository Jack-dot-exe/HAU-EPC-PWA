import { useEffect, useMemo, useState } from "react";
import RegistrationPicker from "../components/RegistrationPicker";
import DynamicFields from "../components/DynamicFields";
import { useChecks } from "../app/checksStore";
import { useProfiles } from "../app/profileStore";
import { useRegistrations } from "../app/registrationStore";
import type {
  AircraftProfile,
  CheckType,
  EngineDef,
  InputFieldKey,
  PowerCheckRecord,
  PowerCheckResult,
  PowerCheckValues,
} from "../domain/models";
import { computeForProfile } from "../calculations";

function makeId(prefix: string) {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() ?? `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now()}`);
}

const ENV_KEYS: InputFieldKey[] = ["TTH", "OAT", "PA"];

function isComplete(values: PowerCheckValues, fields: { key: keyof PowerCheckValues; required?: boolean }[]) {
  return fields.every((f) => {
    if (!f.required) return true;
    const v = values[f.key];
    return typeof v === "number" && !Number.isNaN(v);
  });
}

function getEngines(profile?: AircraftProfile | null): EngineDef[] {
  if (!profile) return [{ id: "1", label: "ENG 1" }];
  if (profile.engines?.length) return profile.engines;
  const n = Math.max(1, profile.engineCount ?? 1);
  return Array.from({ length: n }, (_, i) => ({ id: String(i + 1), label: `ENG ${i + 1}` }));
}

function normalizeValuesForFields(
  prev: PowerCheckValues,
  allowedKeys: Set<InputFieldKey>,
  defaults: Partial<Record<InputFieldKey, number>>,
): PowerCheckValues {
  const next: PowerCheckValues = {};
  for (const k of Object.keys(prev) as InputFieldKey[]) {
    if (allowedKeys.has(k)) next[k] = prev[k];
  }
  for (const [k, v] of Object.entries(defaults) as [InputFieldKey, number][]) {
    if (allowedKeys.has(k) && next[k] === undefined) next[k] = v;
  }
  return next;
}

export default function NewCheckPage() {
  const { addCheck } = useChecks();
  const { profiles } = useProfiles();
  const { registrations } = useRegistrations();

  const [registrationId, setRegistrationId] = useState(registrations[0]?.id ?? "");

  // keep selected registration valid if admin deletes it
  useEffect(() => {
    if (registrations.length === 0) {
      setRegistrationId("");
      return;
    }
    if (!registrations.some((r) => r.id === registrationId)) {
      setRegistrationId(registrations[0].id);
    }
  }, [registrations, registrationId]);

  const reg = useMemo(() => registrations.find((r) => r.id === registrationId), [registrations, registrationId]);
  const profile = useMemo(() => profiles.find((p) => p.id === reg?.profileId), [profiles, reg?.profileId]);

  const engines = useMemo(() => getEngines(profile), [profile]);
  const engineCount = engines.length;

  const checkTypes = profile?.checkTypes ?? (["Ground"] as CheckType[]);
  const [checkType, setCheckType] = useState<CheckType>(checkTypes[0]);

  // keep checkType valid when switching registration/profile
  useEffect(() => {
    if (!checkTypes.includes(checkType)) setCheckType(checkTypes[0]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.id, registrationId]);

  const fields = profile?.inputSchema[checkType] ?? [];
  const envFields = useMemo(() => fields.filter((f) => ENV_KEYS.includes(f.key)), [fields]);
  const engineFields = useMemo(() => fields.filter((f) => !ENV_KEYS.includes(f.key)), [fields]);

  const [activeEngineIdx, setActiveEngineIdx] = useState(0);

  const [envValues, setEnvValues] = useState<PowerCheckValues>({ OAT: 15, PA: 5000 }); // Set constant field values
  const [engineValues, setEngineValues] = useState<PowerCheckValues[]>(
    Array.from({ length: engineCount }, () => ({} as PowerCheckValues)),
  );
  const [computedResults, setComputedResults] = useState<PowerCheckResult[] | null>(null);

  // Keep engineValues array length aligned with engineCount
  useEffect(() => {
    setEngineValues((prev) => {
      if (prev.length === engineCount) return prev;
      if (prev.length < engineCount) {
        return [...prev, ...Array.from({ length: engineCount - prev.length }, () => ({} as PowerCheckValues))];
      }
      return prev.slice(0, engineCount);
    });
    setActiveEngineIdx((i) => Math.min(i, Math.max(0, engineCount - 1)));
    setComputedResults(null);
  }, [engineCount]);

  // Clear values not part of current schema to keep data clean
  useEffect(() => {
    const envAllowed = new Set(envFields.map((f) => f.key));
    const engineAllowed = new Set(engineFields.map((f) => f.key));

    setEnvValues((prev) =>
      normalizeValuesForFields(prev, envAllowed, {
        TTH: undefined,
        OAT: 15,
        PA: 5000,
      }),
    );

    setEngineValues((prev) =>
      prev.map((ev) =>
        normalizeValuesForFields(ev, engineAllowed, {
          // no engine defaults today; keep ready for future
        }),
      ),
    );

    setComputedResults(null);
  }, [checkType, profile?.id, envFields, engineFields]);

  const setEnvValue = (key: keyof PowerCheckValues, value: number | undefined) =>
    setEnvValues((s) => ({ ...s, [key]: value }));

  const setEngineValue = (engineIdx: number, key: keyof PowerCheckValues, value: number | undefined) =>
    setEngineValues((prev) => prev.map((v, i) => (i === engineIdx ? { ...v, [key]: value } : v)));

  const canCompute =
    !!profile &&
    fields.length > 0 &&
    engineValues.length === engineCount &&
    engineValues.every((ev) => isComplete({ ...envValues, ...ev }, fields));

  function onCompute() {
    if (!profile || !canCompute) return;
    try {
      const results = engines.map((_, idx) =>
        computeForProfile(profile, checkType, { ...envValues, ...engineValues[idx] }),
      );
      setComputedResults(results);
    } catch (e) {
      console.error(e);
      alert(e instanceof Error ? e.message : "Compute failed");
      setComputedResults(null);
    }
  }


  // Recordset Save Logic
  function onSave() {
    if (!profile || !computedResults || !registrationId) return;

    const record: PowerCheckRecord = {
      id: makeId("c"),
      createdAtIso: new Date().toISOString(),
      registrationId,
      checkType,
      schemaVersion: 2,
      totalTimeHrs: typeof envValues.ITT === "number" ? envValues.ITT : undefined,
      engines: engines.map((eng, idx) => ({
        engineId: eng.id,
        engineLabel: eng.label,
        values: { ...envValues, ...engineValues[idx] },
        result: computedResults[idx],
      })),
      overallResult: {
        pass: computedResults.every((r) => r.pass),
      },
    };

    addCheck(record);
    setComputedResults(null);
  }

  const overallPass = computedResults?.every((r) => r.pass) ?? false;
  const activeResult = computedResults?.[activeEngineIdx] ?? null;

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <div className="card bg-base-100 shadow lg:col-span-2">
        <div className="card-body">
          <h2 className="card-title">New Power Check</h2>

          {registrations.length === 0 ? (
            <div className="alert alert-warning">
              <span>No registrations configured. Add one in Admin.</span>
            </div>
          ) : (
            <>
              <div className="grid gap-3 md:grid-cols-3">
                <RegistrationPicker
                  registrations={registrations}
                  value={registrationId}
                  onChange={(id) => {
                    setRegistrationId(id);
                    setComputedResults(null);
                  }}
                />

                {/* Aircraft Profile */}
                <div className="flex flex-col gap-1">
                  <label className="label-text label">Aircraft Profile</label>

                  <input
                    className="input input-bordered w-full"
                    value={profile ? `${profile.modelName} (${profile.engine})` : "—"}
                    readOnly
                  />
                </div>

                {/* Check Type */}
                <div className="flex flex-col gap-1">
                  <label className="label-text label">Check Type</label>

                  <select
                    className="select select-bordered w-full"
                    value={checkType}
                    onChange={(e) => {
                      setCheckType(e.target.value as CheckType);
                      setComputedResults(null);
                    }}
                    disabled={!profile}
                  >
                    {checkTypes.map((ct) => (
                      <option key={ct} value={ct}>
                        {ct}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="divider" />

              {!profile ? (
                <div className="alert">
                  <span>This registration has no valid profile assigned.</span>
                </div>
              ) : fields.length === 0 ? (
                <div className="alert alert-warning">
                  <span>No input schema defined for {checkType} on this profile.</span>
                </div>
              ) : (
                <>
                  {/* Environmental inputs (entered once) */}
                  {envFields.length > 0 && (
                    <>
                      <div className="mb-2 text-sm font-semibold">Environment</div>
                      <DynamicFields fields={envFields} values={envValues} setValue={setEnvValue as any} />
                      <div className="divider" />
                    </>
                  )}

                  {/* Per-engine inputs */}
                  {engineCount > 1 && (
                    <div className="tabs tabs-box inset-shadow-sm/12 gap-3 flex justify-center" >
                      {engines.map((eng, idx) => (
                        <button
                          key={eng.id}
                          type="button"
                          className={`tab m-1 px-10 ${idx === activeEngineIdx ? "tab-active shadow-md" : "hover:bg-base-300" }`}
                          onClick={() => setActiveEngineIdx(idx)}
                        >
                          {eng.label}
                        </button>
                      ))}
                    </div>
                  )}

                  {engineFields.length === 0 ? (
                    <div className="alert alert-info">
                      <span>This check type has no engine-specific inputs.</span>
                    </div>
                  ) : (
                    
                    <DynamicFields
                      fields={engineFields}
                      values={engineValues[activeEngineIdx] ?? {}}
                      setValue={((key: keyof PowerCheckValues, value: number | undefined) =>
                        setEngineValue(activeEngineIdx, key, value)) as any}
                    />
                  )}
                </>
              )}

              <div className="mt-4 flex flex-wrap gap-2">
                <button className="btn btn-primary" type="button" disabled={!canCompute} onClick={onCompute}>
                  Compute
                </button>
                <button className="btn btn-outline" type="button" disabled={!computedResults} onClick={onSave}>
                  Save Check
                </button>
              </div>

              {!canCompute && profile && fields.length > 0 && (
                <div className="mt-2 text-xs opacity-70">
                  Fill all required fields (*) for <span className="font-semibold">all engines</span> to compute.
                </div>
              )}
            </>
          )}
        </div>
      </div>

      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <h2 className="card-title">Result</h2>

          {!computedResults ? (
            <div className="alert">
              <span>Enter values for all engines and click Compute.</span>
            </div>
          ) : (
            <>
              {engineCount > 1 && (
                <>
                  <div className={`alert ${overallPass ? "alert-success" : "alert-error"}`}>
                    <span>{overallPass ? "OVERALL PASS" : "OVERALL FAIL"}</span>
                  </div>

                  <div className="tabs tabs-boxed mt-3">
                    {engines.map((eng, idx) => (
                      <button
                        key={eng.id}
                        type="button"
                        className={`tab ${idx === activeEngineIdx ? "tab-active" : ""}`}
                        onClick={() => setActiveEngineIdx(idx)}
                      >
                        {eng.label}
                      </button>
                    ))}
                  </div>
                </>
              )}

              {activeResult && (
                <>
                  <div className="stats stats-vertical bg-base-100 mt-3">
                    <div className="stat">
                      <div className="stat-title">Expected</div>
                      <div className="stat-value text-2xl">{activeResult.expectedPct}%</div>
                    </div>
                    <div className="stat">
                      <div className="stat-title">Actual</div>
                      <div className="stat-value text-2xl">{activeResult.actualPct}%</div>
                    </div>
                    <div className="stat">
                      <div className="stat-title">Delta</div>
                      <div className="stat-value text-2xl">{activeResult.deltaPct}%</div>
                    </div>
                  </div>

                  <div className={`mt-3 alert ${activeResult.pass ? "alert-success" : "alert-error"}`}>
                    <span>{activeResult.pass ? "PASS (within limits)" : "FAIL (outside limits)"}</span>
                  </div>
                </>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
