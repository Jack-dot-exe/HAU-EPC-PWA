import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUsers } from "../app/usersStore";
import { useAuth } from "../app/authStore";

function makeToken() {
  // @ts-ignore
  return globalThis.crypto?.randomUUID?.() ?? `tok_${Math.random().toString(16).slice(2)}_${Date.now()}`;
}

export default function SetupPage() {
  const nav = useNavigate();
  const { bootstrapNeeded, ensureBootstrapAdmin, setUserPassword, setCurrentUserId } = useUsers();
  const { loginWithToken } = useAuth();

  const [pw1, setPw1] = useState("");
  const [pw2, setPw2] = useState("");
  const [busy, setBusy] = useState(false);

  if (!bootstrapNeeded) {
    // Setup already done
    nav("/login", { replace: true });
    return null;
  }

  const admin = ensureBootstrapAdmin();

  async function onSetPassword() {
    if (!pw1 || pw1.length < 8) {
      alert("Password must be at least 8 characters.");
      return;
    }
    if (pw1 !== pw2) {
      alert("Passwords do not match.");
      return;
    }

    setBusy(true);
    try {
      await setUserPassword(admin.id, pw1);
      setCurrentUserId(admin.id);

      // Create a session token and go into the app
      loginWithToken(makeToken());
      nav("/", { replace: true });
    } catch (e) {
      alert(e instanceof Error ? e.message : "Setup failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-md">
      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <h2 className="card-title">Initial Setup</h2>
          <p className="text-sm opacity-70">
            Set the first admin password for this device.
          </p>

          <div className="mt-2">
            <div className="text-sm opacity-70">Admin user</div>
            <div className="font-mono">{admin.email}</div>
          </div>

          <label className="form-control mt-3">
            <div className="label"><span className="label-text">New password</span></div>
            <input
              type="password"
              className="input input-bordered"
              value={pw1}
              onChange={(e) => setPw1(e.target.value)}
              autoComplete="new-password"
            />
          </label>

          <label className="form-control mt-2">
            <div className="label"><span className="label-text">Confirm password</span></div>
            <input
              type="password"
              className="input input-bordered"
              value={pw2}
              onChange={(e) => setPw2(e.target.value)}
              autoComplete="new-password"
              onKeyDown={(e) => {
                if (e.key === "Enter") onSetPassword();
              }}
            />
          </label>

          <button className="btn btn-primary mt-4" onClick={onSetPassword} disabled={busy}>
            {busy ? "Saving..." : "Set admin password"}
          </button>

          <div className="mt-2 text-xs opacity-70">
            After setup, logins require email + password.
          </div>
        </div>
      </div>
    </div>
  );
}
