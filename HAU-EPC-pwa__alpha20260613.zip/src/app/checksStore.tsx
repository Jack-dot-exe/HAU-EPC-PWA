import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { PowerCheckRecord } from "../domain/models";
import { checks as seedChecks } from "../domain/mockData";

type ChecksContextValue = {
  checks: PowerCheckRecord[];
  addCheck: (record: PowerCheckRecord) => void;
  removeCheck: (id: string) => void; // remove dataset for admin only
  resetChecks: () => void;
};

const ChecksContext = createContext<ChecksContextValue | null>(null);

// v2 stores multi-engine-ready records (while keeping legacy fields optional).
const STORAGE_KEY_V2 = "engine-power-checks:v2";
// v1 legacy key (single-engine records)
const STORAGE_KEY_V1 = "engine-power-checks:v1";

function safeParse(json: string | null): unknown {
  if (!json) return null;
  try {
    return JSON.parse(json);
  } catch {
    return null;
  }
}

function isRecordLike(x: any): x is PowerCheckRecord {
  return (
    x &&
    typeof x === "object" &&
    typeof x.id === "string" &&
    typeof x.createdAtIso === "string" &&
    typeof x.registrationId === "string" &&
    typeof x.checkType === "string"
  );
}

function normalizeTotalTimeHrs(input: unknown): number | undefined {
  if (typeof input !== "number") return undefined;
  if (!isFinite(input)) return undefined;
  if (input < 0) return undefined;
  return input;
}

/**
 * Normalize a record so storage is future-proof:
 * - always sanitize totalTimeHrs (once per check)
 * - if schemaVersion is missing/1 and values+result exist => convert to v2 engines[0]
 * - if schemaVersion is 2 but engines missing => attempt best-effort conversion
 */
function normalizeRecord(record: PowerCheckRecord): PowerCheckRecord {
  const totalTimeHrs = normalizeTotalTimeHrs((record as any).totalTimeHrs);

  // Already v2 with engines
  if (record.schemaVersion === 2 && Array.isArray(record.engines) && record.engines.length > 0) {
    return {
      ...record,
      totalTimeHrs,
    };
  }

  // Legacy v1 -> v2 conversion (single-engine)
  if (record.values && record.result) {
    return {
      ...record,
      schemaVersion: 2,
      totalTimeHrs,
      engines: [
        {
          engineId: "1",
          engineLabel: "ENG 1",
          values: record.values ?? {},
          result: record.result,
        },
      ],
      overallResult: {
        pass: record.result.pass,
      },
    };
  }

  // Best effort: mark as v2 but keep whatever is present.
  return {
    ...record,
    schemaVersion: record.schemaVersion ?? 2,
    totalTimeHrs,
    engines: record.engines ?? [],
  };
}

function normalizeRecords(input: unknown): PowerCheckRecord[] | null {
  if (!Array.isArray(input)) return null;
  const records: PowerCheckRecord[] = [];
  for (const item of input) {
    if (!isRecordLike(item)) continue;
    records.push(normalizeRecord(item as PowerCheckRecord));
  }
  return records;
}

function loadInitialChecks(): PowerCheckRecord[] {
  // 1) Prefer v2
  const parsedV2 = safeParse(localStorage.getItem(STORAGE_KEY_V2));
  const fromV2 = normalizeRecords(parsedV2);
  if (fromV2 && fromV2.length > 0) return fromV2;

  // 2) Migrate v1 -> v2 (if present)
  const parsedV1 = safeParse(localStorage.getItem(STORAGE_KEY_V1));
  const fromV1 = normalizeRecords(parsedV1);
  if (fromV1 && fromV1.length > 0) return fromV1;

  // 3) First run uses mock seed
  return seedChecks.map(normalizeRecord);
}

export function ChecksProvider({ children }: { children: React.ReactNode }) {
  const [checks, setChecks] = useState<PowerCheckRecord[]>(() => loadInitialChecks());

  useEffect(() => {
    // Always persist normalized v2 payload.
    localStorage.setItem(STORAGE_KEY_V2, JSON.stringify(checks.map(normalizeRecord)));
  }, [checks]);

  const value = useMemo<ChecksContextValue>(() => {
    return {
      checks,
      addCheck: (record) => setChecks((prev) => [normalizeRecord(record), ...prev]),
      removeCheck: (id) => setChecks((prev) => prev.filter((c) => c.id !== id)),
      resetChecks: () => setChecks(seedChecks.map(normalizeRecord)),
    };
  }, [checks]);

  return <ChecksContext.Provider value={value}>{children}</ChecksContext.Provider>;
}

export function useChecks() {
  const ctx = useContext(ChecksContext);
  if (!ctx) throw new Error("useChecks must be used inside ChecksProvider");
  return ctx;
}
