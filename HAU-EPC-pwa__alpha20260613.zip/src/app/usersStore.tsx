import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { User } from "../domain/models";
import { users as seedUsers } from "../domain/mockData";
import { hashPassword, verifyPassword } from "../security/password";

const USERS_KEY = "engine-power:users:v1";
const CURRENT_USER_KEY = "engine-power:current-user:v1";

type UsersContextValue = {
  users: User[];
  addUser: (u: User) => void;
  updateUser: (id: string, patch: Partial<User>) => void;
  removeUser: (id: string) => void;
  resetUsers: () => void;

  currentUserId: string;
  setCurrentUserId: (id: string) => void;
  currentUser: User | null;

  setUserPassword: (userId: string, newPassword: string) => Promise<void>;
  loginWithEmailPassword: (email: string, password: string) => Promise<User>;

  //For Initial Installation if no ADMIN PW is set
  bootstrapNeeded: boolean;
  ensureBootstrapAdmin: () => User;
};

const UsersContext = createContext<UsersContextValue | null>(null);

function safeParse(json: string | null): User[] | null {
  if (!json) return null;
  try {
    const data = JSON.parse(json);
    return Array.isArray(data) ? (data as User[]) : null;
  } catch {
    return null;
  }
}

export function UsersProvider({ children }: { children: React.ReactNode }) {
  const [users, setUsers] = useState<User[]>(() => {
    const fromStorage = safeParse(localStorage.getItem(USERS_KEY));
    return fromStorage ?? seedUsers;
  });

  const [currentUserId, setCurrentUserIdState] = useState<string>(() => {
    const stored = localStorage.getItem(CURRENT_USER_KEY);
    if (stored) return stored;

    const initial = (safeParse(localStorage.getItem(USERS_KEY)) ?? seedUsers);
    const admin = initial.find((u) => u.role === "admin" && u.isActive);
    return admin?.id ?? initial.find((u) => u.isActive)?.id ?? "";
  });

  useEffect(() => {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    if (currentUserId) localStorage.setItem(CURRENT_USER_KEY, currentUserId);
    else localStorage.removeItem(CURRENT_USER_KEY);
  }, [currentUserId]);

  // keep currentUserId valid if user deleted/disabled
  useEffect(() => {
    if (!currentUserId) return;

    const isValid = users.some((u) => u.id === currentUserId && u.isActive);
    if (!isValid) {
      const admin = users.find((u) => u.role === "admin" && u.isActive);
      setCurrentUserIdState(admin?.id ?? users.find((u) => u.isActive)?.id ?? "");
    }
  }, [users, currentUserId]);

  const value = useMemo<UsersContextValue>(() => {
    const currentUser = users.find((u) => u.id === currentUserId) ?? null;

    const bootstrapNeeded = !users.some(
      (u) => u.isActive && u.passwordSalt && u.passwordHash && u.passwordIterations
    );

    const ensureBootstrapAdmin = () => {
      const admin = users.find((u) => u.isActive && u.role === "admin");
      if (!admin) throw new Error("No active admin user exists. Add one in seed data.");
      return admin;
    };

    return {
      users,
      bootstrapNeeded,
      ensureBootstrapAdmin,

      addUser: (u) => setUsers((prev) => [u, ...prev]),
      updateUser: (id, patch) =>
        setUsers((prev) => prev.map((u) => (u.id === id ? { ...u, ...patch } : u))),
      removeUser: (id) => setUsers((prev) => prev.filter((u) => u.id !== id)),
      resetUsers: () => setUsers(seedUsers),

      currentUserId,
      setCurrentUserId: (id) => setCurrentUserIdState(id),
      currentUser,

      setUserPassword: async (userId: string, newPassword: string) => {
        const { saltB64, hashB64, iterations } = await hashPassword(newPassword);
        setUsers((prev) =>
          prev.map((u) =>
            u.id === userId
              ? {
                  ...u,
                  passwordSalt: saltB64,
                  passwordHash: hashB64,
                  passwordIterations: iterations,
                }
              : u
          )
        );
      },

      loginWithEmailPassword: async (email: string, password: string) => {
        const user =
          users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase()) ?? null;

        if (!user) throw new Error("User not found");
        if (!user.isActive) throw new Error("User is disabled");

        const { passwordSalt, passwordHash, passwordIterations } = user;
        if (!passwordSalt || !passwordHash || !passwordIterations) {
          throw new Error("User has no password set (ask admin to set it).");
        }

        const ok = await verifyPassword(password, passwordSalt, passwordHash, passwordIterations);
        if (!ok) throw new Error("Invalid password");

        return user;
      },
    };
  }, [users, currentUserId]);

  return <UsersContext.Provider value={value}>{children}</UsersContext.Provider>;
}

export function useUsers() {
  const ctx = useContext(UsersContext);
  if (!ctx) throw new Error("useUsers must be used inside UsersProvider");
  return ctx;
}
