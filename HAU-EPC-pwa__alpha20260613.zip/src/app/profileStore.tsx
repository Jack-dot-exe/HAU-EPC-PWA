// src/app/profileStore.tsx
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { AircraftProfile, EngineDef } from "../domain/models";
import { profiles as seedProfiles } from "../domain/mockData";

type ProfilesContextValue = {
  profiles: AircraftProfile[];
  addProfile: (p: AircraftProfile) => void;
  updateProfile: (id: string, patch: Partial<AircraftProfile>) => void;
  removeProfile: (id: string) => void;
  resetProfiles: () => void; // Reset Seed Data
};

const ProfilesContext = createContext<ProfilesContextValue | null>(null);

// v2 adds normalization for engineCount/engines to support multi-engine profiles
const STORAGE_KEY_V2 = "engine-power:profiles:v2";
const STORAGE_KEY_V1 = "engine-power:profiles:v1";

// If you ever need to delete and reset Local Storage, run:
// localStorage.removeItem("engine-power:profiles:v2");
// localStorage.removeItem("engine-power:profiles:v1");

function safeParse(json: string | null): AircraftProfile[] | null {
  if (!json) return null;
  try {
    const data = JSON.parse(json);
    return Array.isArray(data) ? (data as AircraftProfile[]) : null;
  } catch {
    return null;
  }
}

function defaultEngines(engineCount: number): EngineDef[] {
  return Array.from({ length: engineCount }, (_, i) => ({
    id: String(i + 1),
    label: `ENG ${i + 1}`,
  }));
}

function normalizeEngines(
  engines: EngineDef[] | undefined,
  engineCount: number
): EngineDef[] | undefined {
  const count = Math.max(1, Math.floor(engineCount || 1));

  // Keep storage lean for single-engine unless explicitly defined
  if (count === 1) {
    return engines && engines.length > 0 ? engines.slice(0, 1) : undefined;
  }

  // If none provided, generate defaults for multi-engine
  if (!engines || engines.length === 0) {
    return defaultEngines(count);
  }

  // If provided but wrong length, pad/truncate
  const trimmed = engines.slice(0, count);
  if (trimmed.length < count) {
    const existingIds = new Set(trimmed.map((e) => e.id));
    for (let i = trimmed.length; i < count; i++) {
      const id = String(i + 1);
      trimmed.push({
        id: existingIds.has(id) ? `E${id}` : id,
        label: `ENG ${i + 1}`,
      });
    }
  }

  // Ensure ids are unique (best-effort)
  const seen = new Set<string>();
  const uniqued = trimmed.map((e, idx) => {
    let id = (e.id ?? "").trim() || String(idx + 1);
    if (seen.has(id)) {
      id = `${id}_${idx + 1}`;
    }
    seen.add(id);
    return { ...e, id, label: (e.label ?? "").trim() || `ENG ${idx + 1}` };
  });

  return uniqued;
}

function normalizeProfile(p: AircraftProfile): AircraftProfile {
  // Determine engineCount with sane defaults
  const derivedCount =
    (typeof p.engineCount === "number" && isFinite(p.engineCount) ? p.engineCount : undefined) ??
    (p.engines?.length ? p.engines.length : undefined) ??
    1;

  const engineCount = Math.max(1, Math.floor(derivedCount));

  // Normalize engines only when multi-engine or explicitly provided
  const engines = normalizeEngines(p.engines, engineCount);

  return {
    ...p,
    engineCount,
    engines,
  };
}

function normalizeProfiles(list: AircraftProfile[]): AircraftProfile[] {
  return list.map(normalizeProfile);
}

export function ProfilesProvider({ children }: { children: React.ReactNode }) {
  const [profiles, setProfiles] = useState<AircraftProfile[]>(() => {
    const fromV2 = safeParse(localStorage.getItem(STORAGE_KEY_V2));
    if (fromV2) return normalizeProfiles(fromV2);

    const fromV1 = safeParse(localStorage.getItem(STORAGE_KEY_V1));
    if (fromV1) return normalizeProfiles(fromV1);

    return normalizeProfiles(seedProfiles);
  });

  // Persist v2 normalized data. If v1 exists, migrate forward.
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_V2, JSON.stringify(profiles));

    // Optional: if v1 is present, remove it after successful write
    if (localStorage.getItem(STORAGE_KEY_V1)) {
      try {
        localStorage.removeItem(STORAGE_KEY_V1);
      } catch {
        // ignore
      }
    }
  }, [profiles]);

  const value = useMemo<ProfilesContextValue>(() => {
    return {
      profiles,

      addProfile: (p) => setProfiles((prev) => [normalizeProfile(p), ...prev]),

      updateProfile: (id, patch) =>
        setProfiles((prev) =>
          prev.map((p) => {
            if (p.id !== id) return p;
            return normalizeProfile({ ...p, ...patch });
          })
        ),

      removeProfile: (id) => setProfiles((prev) => prev.filter((p) => p.id !== id)),

      resetProfiles: () => setProfiles(normalizeProfiles(seedProfiles)),
    };
  }, [profiles]);

  return <ProfilesContext.Provider value={value}>{children}</ProfilesContext.Provider>;
}

export function useProfiles() {
  const ctx = useContext(ProfilesContext);
  if (!ctx) throw new Error("useProfiles must be used inside ProfilesProvider");
  return ctx;
}
