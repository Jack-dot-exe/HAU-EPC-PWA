import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "./authStore";
import { useUsers } from "./usersStore";

export default function RequireAuth({ children }: { children: JSX.Element }) {
  const { isAuthenticated } = useAuth();
  const { bootstrapNeeded } = useUsers();
  const loc = useLocation();

  // Force initial setup ONLY if no passwords exist AND user is not authenticated
  if (!isAuthenticated && bootstrapNeeded && loc.pathname !== "/setup") {
    return <Navigate to="/setup" replace />;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: loc.pathname }} />;
  }

  return children;
}
