import type { AircraftProfile, PowerCheckRecord, Registration, User } from "./models";

// =======================
// Seed Aircraft Profiles
// =======================
export const profiles: AircraftProfile[] = [
  {
    id: "p_ec135_arrius_2b1_n1",
    modelName: "EC135 (T1)",
    engine: "Arrius 2B1",
    checkTypes: ["In-Flight"],
    limits: { deltaPercentPass: 0 }, // N1 percentage points
    calculationId: "ec135_arrius_2b1_n1",
    engineCount: 2,
    inputSchema: {
      "In-Flight": [
        { key: "TTH", label: "Helicopter Total Time", required: true, step: 0.1, min: 0 },
        { key: "OAT", label: "OAT", unit: "°C", required: true, step: 1, min: -30, max: 50 },
        { key: "PA", label: "Pressure Altitude", unit: "ft", required: true, step: 100, min: 0, max: 10000 },
        { key: "N1", label: "Actual N1", unit: "%", required: true, step: 0.1, min: 80, max: 110 },
        { key: "TRQ", label: "Torque", unit: "%", required: false },
        { key: "TOT", label: "TOT", unit: "°C", required: false },
      ], // use step:0.1 for decimal numbers!
    },
  },

  // Keep a couple generic profiles so other screens still demonstrate multi-model behavior
  {
    id: "p_heli_a",
    modelName: "Helicopter A",
    engine: "Turboshaft X",
    checkTypes: ["Ground", "Hover", "In-Flight"],
    limits: { deltaPercentPass: 5 },
    calculationId: "generic_placeholder",
    inputSchema: {
      Ground: [
        { key: "OAT", label: "OAT", unit: "°C", required: true },
        { key: "PA", label: "Pressure Altitude", unit: "ft", required: true },
        { key: "N1", label: "N1", unit: "%", required: true, step: 0.1 },
      ],
      Hover: [
        { key: "OAT", label: "OAT", unit: "°C", required: true },
        { key: "PA", label: "Pressure Altitude", unit: "ft", required: true },
        { key: "TRQ", label: "Torque", unit: "%", required: true, step: 0.1 },
        { key: "TOT", label: "TOT", unit: "°C", required: true },
      ],
      "In-Flight": [
        { key: "OAT", label: "OAT", unit: "°C", required: true },
        { key: "PA", label: "Pressure Altitude", unit: "ft", required: true },
        { key: "TRQ", label: "Torque", unit: "%", required: true, step: 0.1 },
        { key: "ITT", label: "ITT", unit: "°C", required: true },
        { key: "N1", label: "N1", unit: "%", required: true, step: 0.1 },
      ],
    },
  },

  {
    id: "p_heli_b",
    modelName: "Helicopter B",
    engine: "Turboshaft Y",
    checkTypes: ["Ground", "In-Flight"],
    limits: { deltaPercentPass: 6 },
    calculationId: "generic_placeholder",
    inputSchema: {
      Ground: [
        { key: "OAT", label: "OAT", unit: "°C", required: true },
        { key: "PA", label: "Pressure Altitude", unit: "ft", required: true },
        { key: "N1", label: "N1", unit: "%", required: true, step: 0.1 },
      ],
      "In-Flight": [
        { key: "OAT", label: "OAT", unit: "°C", required: true },
        { key: "PA", label: "Pressure Altitude", unit: "ft", required: true },
        { key: "TRQ", label: "Torque", unit: "%", required: true, step: 0.1 },
        { key: "ITT", label: "ITT", unit: "°C", required: true },
      ],
    },
  },
];

// =======================
// Seed Registrations
// =======================
export const registrations: Registration[] = [
  { id: "r_ec135", tailNumber: "D-EC135", profileId: "p_ec135_arrius_2b1_n1" },
  { id: "r_dhabc", tailNumber: "D-HABC", profileId: "p_heli_a" },
  { id: "r_dhxyz", tailNumber: "D-HXYZ", profileId: "p_heli_b" },
];

// =======================
// Seed Users
// =======================
export const users: User[] = [
  { id: "u_admin", email: "admin@example.com", role: "admin", isActive: true },
  { id: "u_editor", email: "editor@example.com", role: "editor", isActive: true },
  { id: "u_view", email: "viewer@example.com", role: "viewer", isActive: true },
];

// =======================
// Seed History (Checks) used by ChecksProvider only on first run
// =======================
export const checks: PowerCheckRecord[] = [
  {
    id: "c_seed_1",
    createdAtIso: new Date(Date.now() - 86400000 * 14).toISOString(),
    registrationId: "r_ec135",
    checkType: "Ground",
    values: { TTH: 2550.25 , OAT: 5, PA: 2500, N1: 91.0 },
    result: { expectedPct: 92.2, actualPct: 91.0, deltaPct: 1.2, pass: true }, // seed example
  },
];
