import type { AircraftProfile, CheckType, PowerCheckValues } from "../domain/models";
import { computeEc135Arrius2B1N1 } from "./ec135/ec135_n1_calc";
import { clamp, round1 } from "./utils/interp";

export function computeForProfile(profile: AircraftProfile, checkType: CheckType, values: PowerCheckValues) {
  const passLimit = profile.limits.deltaPercentPass;

  switch (profile.calculationId) {
    case "ec135_arrius_2b1_n1":
      return computeEc135Arrius2B1N1(checkType, values, passLimit);

    case "generic_placeholder":
    default: {
      const oat = values.OAT ?? 15;
      const pa = values.PA ?? 0;

      const expected = clamp(100 - pa / 300 - Math.max(0, oat - 15) * 0.5, 40, 100);
      const actual = clamp(
        60 + (values.TRQ ?? values.N1 ?? 70) * 0.4 + (values.ITT ?? values.TOT ?? 600) * 0.01,
        40,
        110
      );

      const delta = actual - expected;

      return {
        expectedPct: round1(expected),
        actualPct: round1(actual),
        deltaPct: round1(delta),
        pass: Math.abs(delta) <= passLimit,
      };
    }
  }
}
