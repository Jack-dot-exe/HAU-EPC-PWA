# Supabase Setup

1. Create a Supabase project.
2. In Supabase Auth settings, enable Email/Password sign-in.
3. Open SQL Editor and run `supabase/schema.sql`.
4. Copy `.env.example` to `.env` and set:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_DEFAULT_KEY`
5. Restart the Vite dev server.

## Current behavior

- If Supabase env vars are present, app uses Supabase for users/roles, profiles, registrations, checks, and auth session handling.
- If env vars are missing, app keeps using local storage fallback for development only.

## Bootstrap flow

- First login/setup should be done through the app's `/setup` page.
- The first authenticated user is allowed to create exactly one `admin` row in `epc_users` (bootstrap policy).

## Security model

- `viewer`: read-only access
- `editor`: read + write checks/profiles/registrations
- `admin`: full access including user/role management

## Important

- Users created from the admin panel are added without an initial password.
- They set their own first password on the login page after entering their email.
- When `schema.sql` changes, re-run it in Supabase SQL editor so policies/functions stay in sync.
