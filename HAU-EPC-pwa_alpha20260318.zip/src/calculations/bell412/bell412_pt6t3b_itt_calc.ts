import type { CheckType, PowerCheckResult, PowerCheckValues } from "../../domain/models";
import { clamp, interp1D, round1 } from "../utils/interp";

type XY = { x: number; y: number };

const TRQ_TO_Y_BY_PA: Record<number, { x1: number; y1: number; x2: number; y2: number }> = {
  0: { x1: 73.6, y1: 0, x2: 40, y2: 18.6 },
  2000: { x1: 68.65, y1: 0, x2: 40, y2: 16.27 },
  4000: { x1: 63.64, y1: 0, x2: 40, y2: 14.21 },
  6000: { x1: 58.33, y1: 0, x2: 40, y2: 12.28 },
  8000: { x1: 54.1, y1: 0, x2: 40, y2: 9.678 },
  10000: { x1: 49.31, y1: 0, x2: 40, y2: 7 },
};

const ITT_CURVES_BY_OAT: Record<number, XY[]> = {
  "-50": [{ x: 490, y: 18 }, { x: 510, y: 15.6 }, { x: 550, y: 10.85 }, { x: 600, y: 5.918 }, { x: 650, y: 1.7 }, { x: 674.3, y: 0 }],
  "-40": [{ x: 524.6, y: 17.58 }, { x: 550, y: 14.43 }, { x: 600, y: 9 }, { x: 650, y: 4.23 }, { x: 700, y: 0.578 }, { x: 710.5, y: 0 }],
  "-30": [{ x: 558.5, y: 17.13 }, { x: 600, y: 12.27 }, { x: 650, y: 7.175 }, { x: 700, y: 2.8 }, { x: 724.7, y: 1.04 }, { x: 743.3, y: 0 }],
  "-20": [{ x: 593.13, y: 16.67 }, { x: 650, y: 10.22 }, { x: 700, y: 5.48 }, { x: 750, y: 1.56 }, { x: 774.76, y: 0 }],
  "-10": [{ x: 626.6, y: 16.2 }, { x: 650, y: 13.57 }, { x: 700, y: 8.446 }, { x: 750, y: 4.15 }, { x: 800, y: 0.482 }, { x: 808, y: 0 }],
  0: [{ x: 661.63, y: 15.74 }, { x: 700, y: 11.39 }, { x: 750, y: 6.63 }, { x: 800, y: 2.47 }, { x: 822, y: 1 }, { x: 842.6, y: 0 }],
  10: [{ x: 694.67, y: 15.2 }, { x: 730, y: 11.55 }, { x: 750, y: 9.58 }, { x: 822, y: 3.31 }, { x: 878.4, y: 0 }],
  20: [{ x: 730, y: 14.79 }, { x: 772, y: 10.45 }, { x: 821.5, y: 6.05 }, { x: 865, y: 2.8 }, { x: 920, y: 0 }],
  30: [{ x: 765, y: 14.3 }, { x: 793, y: 11.41 }, { x: 821.4, y: 8.841 }, { x: 900, y: 2.976 }, { x: 960, y: 0 }],
  40: [{ x: 799.5, y: 13.856 }, { x: 822, y: 11.526 }, { x: 852.76, y: 8.814 }, { x: 936, y: 2.987 }, { x: 1000, y: 0 }],
};

function sortedNumericKeys<T extends Record<number, unknown>>(obj: T): number[] {
  return Object.keys(obj).map(Number).sort((a, b) => a - b);
}

function yFromTrqAtPa(trq: number, pa: number): number {
  const paLevels = sortedNumericKeys(TRQ_TO_Y_BY_PA);
  const paClamped = clamp(pa, paLevels[0], paLevels[paLevels.length - 1]);

  const lower = paLevels.filter((p) => p <= paClamped).pop() ?? paLevels[0];
  const upper = paLevels.find((p) => p >= paClamped) ?? paLevels[paLevels.length - 1];

  const yOnPa = (paLine: number) => {
    const line = TRQ_TO_Y_BY_PA[paLine];
    const trqClamped = clamp(trq, Math.min(line.x1, line.x2), Math.max(line.x1, line.x2));
    return interp1D(trqClamped, line.x1, line.y1, line.x2, line.y2);
  };

  const yLow = yOnPa(lower);
  const yHigh = yOnPa(upper);
  if (lower === upper) return yLow;
  return interp1D(paClamped, lower, yLow, upper, yHigh);
}

function xOnIttCurveForY(oatLine: number, y: number): number {
  const pts = [...ITT_CURVES_BY_OAT[oatLine]].sort((a, b) => a.y - b.y);
  if (!pts.length) throw new Error(`Missing Bell 412 ITT curve for OAT=${oatLine}`);

  const minY = pts[0].y;
  const maxY = pts[pts.length - 1].y;
  const yClamped = clamp(y, minY, maxY);

  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    if (yClamped >= a.y && yClamped <= b.y) {
      return interp1D(yClamped, a.y, a.x, b.y, b.x);
    }
  }
  return pts[pts.length - 1].x;
}

function expectedBell412MaxItt(oat: number, y: number): number {
  const oatLevels = sortedNumericKeys(ITT_CURVES_BY_OAT);
  const oatClamped = clamp(oat, oatLevels[0], oatLevels[oatLevels.length - 1]);

  const lower = oatLevels.filter((t) => t <= oatClamped).pop() ?? oatLevels[0];
  const upper = oatLevels.find((t) => t >= oatClamped) ?? oatLevels[oatLevels.length - 1];

  const xLow = xOnIttCurveForY(lower, y);
  const xHigh = xOnIttCurveForY(upper, y);
  if (lower === upper) return xLow;
  return interp1D(oatClamped, lower, xLow, upper, xHigh);
}

export function computeBell412PwPt6t3bItt(
  checkType: CheckType,
  values: PowerCheckValues,
  passLimit: number
): PowerCheckResult {
  if (checkType !== "In-Flight") {
    throw new Error(`Bell 412 ITT calculation only supports In-Flight (got ${checkType})`);
  }

  const oat = values.OAT ?? 15;
  const pa = values.PA ?? 5000;
  const trq = values.TRQ;
  const actualItt = values.ITT;

  if (typeof trq !== "number" || Number.isNaN(trq)) throw new Error("Torque (TRQ) is required");
  if (typeof actualItt !== "number" || Number.isNaN(actualItt)) throw new Error("Actual ITT is required");

  const y = yFromTrqAtPa(trq, pa);
  const expectedItt = expectedBell412MaxItt(oat, y);
  const delta = expectedItt - actualItt;
  const pass = actualItt <= expectedItt + passLimit;

  return {
    expectedPct: round1(expectedItt),
    actualPct: round1(actualItt),
    deltaPct: round1(delta),
    pass,
  };
}
