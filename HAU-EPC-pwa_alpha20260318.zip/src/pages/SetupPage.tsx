import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { useUsers } from "../app/usersStore";
import { useAuth } from "../app/authStore";
import { isSupabaseEnabled } from "../lib/supabase";
import PasswordPolicyChecklist from "../components/PasswordPolicyChecklist";
import {
  evaluatePasswordPolicy,
  isPasswordPolicyValid,
  PASSWORD_POLICY_ERROR_TEXT,
} from "../security/passwordPolicy";

export default function SetupPage() {
  const nav = useNavigate();
  const {
    bootstrapNeeded,
    ensureBootstrapAdmin,
    users,
    setUserPassword,
    ensureUserFromAuth,
    updateUser,
  } = useUsers();
  const { loginWithToken, registerWithPassword } = useAuth();

  const [pw1, setPw1] = useState("");
  const [pw2, setPw2] = useState("");
  const [showPw1, setShowPw1] = useState(false);
  const [showPw2, setShowPw2] = useState(false);
  const seededAdmin = users.find((u) => u.role === "admin" && u.isActive) ?? null;
  const [adminEmail, setAdminEmail] = useState(seededAdmin?.email ?? "");
  const [busy, setBusy] = useState(false);
  const passwordRules = evaluatePasswordPolicy(pw1);
  const passwordValid = isPasswordPolicyValid(passwordRules);
  const passwordsMatch = pw1.length > 0 && pw1 === pw2;

  if (!bootstrapNeeded) {
    // Setup already done
    return <Navigate to="/login" replace />;
  }

  const admin = isSupabaseEnabled ? seededAdmin : ensureBootstrapAdmin();

  async function onSetPassword() {
    if (!passwordValid) {
      alert(PASSWORD_POLICY_ERROR_TEXT);
      return;
    }
    if (!passwordsMatch) {
      alert("Passwords do not match.");
      return;
    }
    const targetEmail = (adminEmail || admin?.email || "").trim().toLowerCase();
    if (isSupabaseEnabled && !targetEmail) {
      alert("Admin email is required.");
      return;
    }

    setBusy(true);
    try {
      if (isSupabaseEnabled) {
        const authUser = await registerWithPassword(targetEmail, pw1);
        const appUser = await ensureUserFromAuth(authUser.id, authUser.email, "admin");
        updateUser(appUser.id, { role: "admin", isActive: true });
      } else {
        if (!admin) throw new Error("No bootstrap admin user available.");
        await setUserPassword(admin.id, pw1);
        await registerWithPassword(admin.email, pw1);
        loginWithToken(`local_${Date.now()}`);
      }
      nav("/", { replace: true });
    } catch (e) {
      alert(e instanceof Error ? e.message : "Setup failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-md">
      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <h2 className="card-title">Initial Setup</h2>
          <p className="text-sm opacity-70">
            Set the first admin password for this device.
          </p>

          <div className="mt-2">
            <div className="text-sm opacity-70">Admin user</div>
            {isSupabaseEnabled ? (
              <input
                type="email"
                className="input input-bordered w-full font-mono"
                placeholder="admin@example.com"
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
              />
            ) : (
              <div className="font-mono">{admin?.email}</div>
            )}
          </div>

          <label className="form-control mt-3">
            <div className="label"><span className="label-text">New password</span></div>
            <div className="relative">
              <input
                type={showPw1 ? "text" : "password"}
                className="input input-bordered w-full pr-12"
                value={pw1}
                onChange={(e) => setPw1(e.target.value)}
                autoComplete="new-password"
              />
              <button
                type="button"
                className="btn btn-ghost btn-sm absolute right-1 top-1/2 -translate-y-1/2"
                onClick={() => setShowPw1((v) => !v)}
                aria-label={showPw1 ? "Hide password" : "Show password"}
              >
                {showPw1 ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3l18 18M10.58 10.58A2 2 0 0012 14a2 2 0 001.42-.58M9.88 5.09A9.77 9.77 0 0112 5c5 0 9 4.5 9 7-0 1.12-.82 2.62-2.2 4M6.1 6.1C3.9 7.45 2.3 9.43 2 12c0 2.5 4 7 10 7 1.87 0 3.58-.5 5.03-1.3" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z" />
                    <circle cx="12" cy="12" r="3" strokeWidth="2" />
                  </svg>
                )}
              </button>
            </div>
          </label>

          <PasswordPolicyChecklist result={passwordRules} />

          <label className="form-control mt-2">
            <div className="label"><span className="label-text">Confirm password</span></div>
            <div className="relative">
              <input
                type={showPw2 ? "text" : "password"}
                className="input input-bordered w-full pr-12"
                value={pw2}
                onChange={(e) => setPw2(e.target.value)}
                autoComplete="new-password"
                onKeyDown={(e) => {
                  if (e.key === "Enter") onSetPassword();
                }}
              />
              <button
                type="button"
                className="btn btn-ghost btn-sm absolute right-1 top-1/2 -translate-y-1/2"
                onClick={() => setShowPw2((v) => !v)}
                aria-label={showPw2 ? "Hide password" : "Show password"}
              >
                {showPw2 ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3l18 18M10.58 10.58A2 2 0 0012 14a2 2 0 001.42-.58M9.88 5.09A9.77 9.77 0 0112 5c5 0 9 4.5 9 7-0 1.12-.82 2.62-2.2 4M6.1 6.1C3.9 7.45 2.3 9.43 2 12c0 2.5 4 7 10 7 1.87 0 3.58-.5 5.03-1.3" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z" />
                    <circle cx="12" cy="12" r="3" strokeWidth="2" />
                  </svg>
                )}
              </button>
            </div>
          </label>
          {pw2.length > 0 && !passwordsMatch && (
            <div className="mt-1 text-xs text-error">Passwords do not match.</div>
          )}

          <button
            className="btn btn-primary mt-4"
            onClick={onSetPassword}
            disabled={busy || !passwordValid || !passwordsMatch}
          >
            {busy ? "Saving..." : "Set admin password"}
          </button>

          <div className="mt-2 text-xs opacity-70">
            After setup, logins require email + password.
          </div>
        </div>
      </div>
    </div>
  );
}
