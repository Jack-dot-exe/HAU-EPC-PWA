import { useEffect, useMemo, useState } from "react";
import { useProfiles } from "../app/profileStore";
import { useRegistrations } from "../app/registrationStore";
import { useUsers } from "../app/usersStore";
import { useChecks } from "../app/checksStore";
import { isSupabaseEnabled } from "../lib/supabase";
import type { Role, EngineDef, AircraftProfile, Registration } from "../domain/models";
import ConfirmDeleteModal from "../components/ConfirmDeleteModal";

function makeId(prefix: string) {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() ?? `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now()}`);
}

export default function AdminPage() {
const { profiles, resetProfiles } = useProfiles();
const { registrations, addRegistration, updateRegistration, removeRegistration, resetRegistrations } = useRegistrations();
const { users, addUser, updateUser, removeUser, resetUsers } = useUsers();
const { resetChecks } = useChecks();
const { setUserPassword } = useUsers();

  // Add Registration form
  const [tailNumber, setTailNumber] = useState("");
  const [profileId, setProfileId] = useState(profiles[0]?.id ?? "");

  // Add User form
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<Role>("viewer");

  // import profiles
  const profileById = useMemo<Map<string, AircraftProfile>>(
    () => new Map(profiles.map(p => [p.id, p])),
    [profiles]
  );

function getProfileEngineDefs(p: AircraftProfile | undefined): EngineDef[] {
  if (!p) return [{ id: "1", label: "ENG 1" }];
  if (Array.isArray(p.engines) && p.engines.length > 0) return p.engines;
  const count = Math.max(1, p.engineCount ?? 1);
  return Array.from({ length: count }, (_, i) => ({ id: String(i + 1), label: `ENG ${i + 1}` }));
}

function getEffectiveEngines(r: Registration): EngineDef[] {
  const p = profileById.get(r.profileId);
  const base = getProfileEngineDefs(p);
  if (!r.engines || r.engines.length === 0) return base;
  // Merge by id so profile updates (like engineCount) can still show missing engines.
  const byId = new Map(base.map(e => [e.id, e]));
  for (const e of r.engines) byId.set(e.id, e);
  return Array.from(byId.values());
}

useEffect(() => {
  if (!profiles.some((p) => p.id === profileId)) {
    setProfileId(profiles[0]?.id ?? "");
  }
}, [profiles, profileId]);
  return (
    <div className="grid gap-4">
      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <h2 className="card-title">Admin Panel</h2>
          <p className="opacity-70">
            Registrations ↔ profiles, users & access rights. Changes persist locally and affect New Check + History immediately.
          </p>
        </div>
      </div>

      {/* Registrations */}
      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <div className="flex items-center justify-between gap-3">
            <h3 className="font-semibold">Registrations</h3>
          </div>

          <div className="mt-3 grid gap-3 md:grid-cols-3">
            <label className="form-control">
              <div className="label"><span className="label-text">Tail number</span></div>
              <input
                className="input input-bordered"
                placeholder="e.g. D-HABC"
                value={tailNumber}
                onChange={(e) => setTailNumber(e.target.value)}
              />
            </label>

            <label className="form-control">
              <div className="label"><span className="label-text">Profile</span></div>
              <select
                className="select select-bordered"
                value={profileId}
                onChange={(e) => setProfileId(e.target.value)}
              >
                {profiles.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.modelName} ({p.engine})
                  </option>
                ))}
              </select>
            </label>

            <div className="flex items-end">
              <button
                className="btn btn-primary w-full"
                disabled={!tailNumber.trim() || !profileId}
                onClick={() => {
                  addRegistration({
                    id: makeId("r"),
                    tailNumber: tailNumber.trim().toUpperCase(),
                    profileId,
                  });
                  setTailNumber("");
                }}
              >
                Add registration
              </button>
            </div>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="table table-zebra">
              <thead>
                <tr>
                  <th>Tail</th>
                  <th>Profile</th>
                  <th>Engines</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {registrations.map((r) => {
                  const p = profileById.get(r.profileId);
                  return (
                    <tr key={r.id}>
                      <td>
                        <input
                          className="input input-bordered input-sm font-mono"
                          value={r.tailNumber}
                          onChange={(e) => {
                            const next = e.target.value.toUpperCase();
                            updateRegistration(r.id, { tailNumber: next });
                          }}
                          placeholder="e.g. D-HABC"
                        />
                      </td>
                      <td>
                        <select
                          className="select select-bordered select-sm"
                          value={r.profileId}
                          onChange={(e) => updateRegistration(r.id, { profileId: e.target.value })}
                        >
                          {profiles.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.modelName}
                            </option>
                          ))}
                        </select>
                        <div className="text-xs opacity-70">
                          {p ? `${p.modelName} (${p.engine})` : "—"}
                        </div>

                      </td>
                        <td className="w-50">
                          {(() => { // Engine Labels - Do not safe into 
                            const engines = getEffectiveEngines(r);
                            const isOverridden = !!(r.engines && r.engines.length > 0);
                            return (
                              <div className="grid gap-2 center-h">
                                <div className="flex flex-wrap items-center gap-2">
                                  <span className="text-xs opacity-70">
                                    {engines.length} engine{engines.length === 1 ? "" : "s"}
                                    {isOverridden ? " (override)" : ""}
                                  </span>

                                  {!isOverridden && (
                                    <button
                                      className="btn btn-ghost btn-xs"
                                      onClick={() => updateRegistration(r.id, { engines })}
                                      title="Create per-registration engine label override"
                                    >
                                      Override labels
                                    </button>
                                  )}

                                  {isOverridden && (
                                    <button
                                      className="btn btn-ghost btn-xs"
                                      onClick={() => updateRegistration(r.id, { engines: undefined })}
                                      title="Remove per-registration override and use profile defaults"
                                    >
                                      Clear Engine Label
                                    </button>
                                  )}
                                </div>

                                {isOverridden ? (
                                  <div className="grid gap-2">
                                    {engines.map((e, idx) => (
                                      <label key={e.id} className="flex items-center gap-2">
                                        <span className="w-14 text-xs opacity-70">{e.id}</span>
                                        <input
                                          className="input input-bordered input-xs "
                                          value={e.label}
                                          onChange={(ev) => {
                                            const next = engines.map((x) =>
                                              x.id === e.id ? { ...x, label: ev.target.value } : x
                                            );
                                            updateRegistration(r.id, { engines: next });
                                          }}
                                          placeholder={`Engine ${idx + 1} label`}
                                        />
                                      </label>
                                    ))}
                                  </div>
                                ) : (
                                  <div className="flex flex-wrap gap-2">
                                    {engines.map((e) => (
                                      <span key={e.id} className="badge badge-ghost">
                                        {e.label}
                                      </span>
                                    ))}
                                  </div>
                                )}
                              </div>
                            );
                          })()}
                        </td>
                        <td className="text-right w-20">
                          <ConfirmDeleteModal
                            title="Delete Registration"
                            message={`Are you sure you want to delete "${r.tailNumber}"?\nThis action cannot be undone.`}
                            onConfirm={() => removeRegistration(r.id)}
                          />

                        {/*<button className="btn btn-xs btn-warning btn-outline" onClick={() => removeRegistration(r.id)}>
                          Delete
                        </button> */}
                      </td>
                    </tr>
                  );
                })}
                {registrations.length === 0 && (
                  <tr>
                    <td colSpan={4} className="opacity-70">No registrations yet.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Profiles (read-only list for now) */}
      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <h3 className="font-semibold">Aircraft Profiles</h3>
          <p className="text-sm opacity-70">Configured and preset aircraft profiles.</p>

          <div className="mt-3 overflow-x-auto">
            <table className="table table-zebra">
              <thead>
                <tr>
                  <th>Model</th>
                  <th>Engine</th>
                  <th>Check types</th>
                </tr>
              </thead>
              <tbody>
                {profiles.map((p) => (
                  <tr key={p.id}>
                    <td>{p.modelName}</td>
                    <td className="text-sm opacity-80">{p.engine}</td>
                    <td className="text-sm">{p.checkTypes.join(", ")}</td>
                  </tr>
                ))}
                {profiles.length === 0 && (
                  <tr>
                    <td colSpan={4} className="opacity-70">No profiles yet.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Users */}
      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <h3 className="font-semibold">Users & Access Rights</h3>

          <div className="mt-3 grid gap-3 md:grid-cols-3">
            <label className="form-control">
              <div className="label"><span className="label-text">Email</span></div>
              <input
                className="input input-bordered"
                placeholder="user@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </label>

            <label className="form-control">
              <div className="label"><span className="label-text">Role</span></div>
              <select className="select select-bordered" value={role} onChange={(e) => setRole(e.target.value as Role)}>
                <option value="viewer">viewer</option>
                <option value="editor">editor</option>
                <option value="admin">admin</option>
              </select>
            </label>

            <div className="flex items-end">
              <button
                className="btn btn-primary w-full"
                disabled={!email.trim()}
                onClick={async () => {
                  addUser({
                    id: makeId("u"),
                    email: email.trim().toLowerCase(),
                    role,
                    isActive: true,
                    ...(isSupabaseEnabled
                      ? { passwordSalt: "__PENDING_INITIAL_PASSWORD__" }
                      : {}),
                  });
                  setEmail("");
                  setRole("viewer");
                }}
              >
                Add user
              </button>
            </div>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="table table-zebra">
              <thead>
                <tr>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Set Password</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id}>
                    <td>{u.email}</td>
                    <td>
                      <select
                        className="select select-bordered select-sm"
                        value={u.role}
                        onChange={(e) => updateUser(u.id, { role: e.target.value as Role })}
                      >
                        <option value="viewer">viewer</option>
                        <option value="editor">editor</option>
                        <option value="admin">admin</option>
                      </select>
                    </td>
                    <td>
                      <button
                        className={`btn btn-xs ${u.isActive ? "btn-success" : "btn-ghost"}`}
                        onClick={() => updateUser(u.id, { isActive: !u.isActive })}
                      >
                        {u.isActive ? "Active" : "Disabled"}
                      </button>
                      {u.passwordSalt === "__PENDING_INITIAL_PASSWORD__" && (
                        <span className="badge badge-warning badge-xs ml-2">Password pending</span>
                      )}
                    </td>
                    <td>
                      <button
                        className="btn btn-xs btn-outline"
                        onClick={async () => {
                          const pw = prompt(`Set new password for ${u.email}:`);
                          if (!pw) return;
                          await setUserPassword(u.id, pw);
                          alert("Password set.");
                        }}
                      >
                        Set password
                      </button>
                    </td>
                    <td className="text-right">
                      <button className="btn btn-xs btn-outline" onClick={() => removeUser(u.id)}>
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
                {users.length === 0 && (
                  <tr>
                    <td colSpan={5} className="opacity-70">No users yet.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-2 text-xs opacity-70">
            Next: delete Rights management from within admin .. not neccessary for production version
          </div>
        </div>
      </div>
      {/*DEVELOPMENT CARD*/}
      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <h3 className="font-semibold">DEVELOPMENT Data Tools</h3>
          <p className="text-sm opacity-70">
            Clear stored cloud data for selected domains.
          </p>

          <div className="mt-3 flex flex-wrap gap-2">
            <button
              className="btn btn-outline btn-sm"
              onClick={() => {
                if (confirm("Clear all PROFILES from the database?")) resetProfiles();
              }}
            >
              Clear Profiles
            </button>

            <button
              className="btn btn-outline btn-sm"
              onClick={() => {
                if (confirm("Clear all REGISTRATIONS from the database?")) resetRegistrations();
              }}
            >
              Clear Registrations
            </button>

            <button
              className="btn btn-outline btn-sm"
              onClick={() => {
                if (confirm("Reset USERS back to seed data?")) resetUsers();
              }}
            >
              Reset Users
            </button>

            <button
              className="btn btn-outline btn-sm"
              onClick={() => {
                if (confirm("Clear all CHECKS from the database?")) resetChecks();
              }}
            >
              Clear Checks
            </button>
          </div>

          <div className="mt-2 text-xs opacity-70">
            Tip: local profile/registration/check history keys are removed after migration to cloud.
          </div>
        </div>
      </div>
    </div>
  );
}

