import type { Registration } from "../domain/models";

export default function RegistrationPicker(props: {
  registrations: Registration[];
  value: string;
  onChange: (registrationId: string) => void;
}) {
  return (
  
    <div className="flex flex-col gap-1">
      <label className="label-text label">Registration</label>

      <select
        className="select select-bordered"
        value={props.value}
        onChange={(e) => props.onChange(e.target.value)}
        >
        {props.registrations.map((r) => (
        <option key={r.id} value={r.id}>
          {r.tailNumber}
        </option>
          ))}
        </select>
    </div>
 
  );
}


    {/* 
    <label className="form-control">
      <div className="label">
        <span className="label-text">Registration</span>
      </div>
      <select
        className="select select-bordered"
        value={props.value}
        onChange={(e) => props.onChange(e.target.value)}
      >
        {props.registrations.map((r) => (
          <option key={r.id} value={r.id}>
            {r.tailNumber}
          </option>
        ))}
      </select>
    </label>*/}