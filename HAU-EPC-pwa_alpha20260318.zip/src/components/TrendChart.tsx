import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";
import type { PowerCheckRecord } from "../domain/models";

type ChartPoint = {
  // X axis now: Total Time (hours)
  tt: number;
  ttLabel: string;

  // keep date around for tooltip context (optional but nice)
  dateLabel: string;

  // Primary engine series
  delta: number;
  trend?: number;

  // Secondary engine series (only if multi-engine)
  delta2?: number;
  trend2?: number;
};

function linearRegression(xs: number[], ys: number[]) {
  const n = xs.length;
  const meanX = xs.reduce((a, b) => a + b, 0) / n;
  const meanY = ys.reduce((a, b) => a + b, 0) / n;

  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    const dx = xs[i] - meanX;
    num += dx * (ys[i] - meanY);
    den += dx * dx;
  }

  const slope = den === 0 ? 0 : num / den;
  const intercept = meanY - slope * meanX;
  return { slope, intercept };
}

function round1(v: number) {
  return Math.round(v * 10) / 10;
}

function getDeltaForEngine(record: PowerCheckRecord, engineId: string): number | null {
  const anyRec: any = record as any;

  // v2 multi-engine
  if (Array.isArray(anyRec.engines) && anyRec.engines.length > 0) {
    const e = anyRec.engines.find((x: any) => String(x.engineId) === String(engineId)) ?? anyRec.engines[0];
    const d = e?.result?.deltaPct;
    return typeof d === "number" && Number.isFinite(d) ? d : null;
  }

  // v1 single-engine
  const d = anyRec.result?.deltaPct;
  return typeof d === "number" && Number.isFinite(d) ? d : null;
}

function getEngineOptions(records: PowerCheckRecord[]) {
  const map = new Map<string, string>(); // id -> label
  for (const r of records) {
    const anyRec: any = r as any;
    if (Array.isArray(anyRec.engines) && anyRec.engines.length > 0) {
      for (const e of anyRec.engines) {
        const id = String(e.engineId ?? "1");
        const label = String(e.engineLabel ?? `ENG ${id}`);
        if (!map.has(id)) map.set(id, label);
      }
    }
  }

  const list = Array.from(map.entries()).map(([engineId, engineLabel]) => ({ engineId, engineLabel }));
  if (list.length === 0) return [{ engineId: "1", engineLabel: "ENG 1" }];

  list.sort((a, b) => {
    const an = Number(a.engineId);
    const bn = Number(b.engineId);
    if (Number.isFinite(an) && Number.isFinite(bn)) return an - bn;
    return a.engineId.localeCompare(b.engineId);
  });

  return list;
}

// --- NEW: Total Time (TT) extraction --------------------------------------

function getEffectiveTotalTimeHrs(record: PowerCheckRecord): number | undefined {
  const anyRec: any = record as any;

  // v2 preferred
  if (typeof anyRec.totalTimeHrs === "number" && Number.isFinite(anyRec.totalTimeHrs) && anyRec.totalTimeHrs >= 0) {
    return anyRec.totalTimeHrs;
  }

  // v1: record.values.TTH
  const v: any = anyRec.values;
  if (v && typeof v.TTH === "number" && Number.isFinite(v.TTH) && v.TTH >= 0) return v.TTH;

  // v2 multi-engine: sometimes copied into engine values
  if (Array.isArray(anyRec.engines)) {
    for (const e of anyRec.engines) {
      const ev: any = e?.values;
      if (ev && typeof ev.TTH === "number" && Number.isFinite(ev.TTH) && ev.TTH >= 0) return ev.TTH;
    }
  }

  // optional: shared/env locations
  const sv: any = anyRec.sharedValues ?? anyRec.environment ?? anyRec.env;
  if (sv && typeof sv.TTH === "number" && Number.isFinite(sv.TTH) && sv.TTH >= 0) return sv.TTH;

  return undefined;
}

function formatTTLabel(tt: number) {
  // Show hours with 1 decimal, but without trailing ".0"
  const s = (Math.round(tt * 10) / 10).toString();
  return s.endsWith(".0") ? s.slice(0, -2) : s;
}

// -------------------------------------------------------------------------

function toChartData(records: PowerCheckRecord[], engineId1: string, engineId2?: string): ChartPoint[] {
  // Sort by TT (fallback: createdAt) so the line progresses left-to-right meaningfully
  const sorted = records
    .slice()
    .sort((a, b) => {
      const ta = getEffectiveTotalTimeHrs(a);
      const tb = getEffectiveTotalTimeHrs(b);
      if (typeof ta === "number" && typeof tb === "number") return ta - tb;
      if (typeof ta === "number") return -1;
      if (typeof tb === "number") return 1;
      return a.createdAtIso.localeCompare(b.createdAtIso);
    });

  const base: ChartPoint[] = sorted
    .map((r) => {
      const d1 = getDeltaForEngine(r, engineId1);
      const d2 = engineId2 ? getDeltaForEngine(r, engineId2) : null;

      // Require TT for X axis; if missing, drop point (keeps chart correct)
      const tt = getEffectiveTotalTimeHrs(r);
      if (typeof tt !== "number") return null;

      // Require primary delta too
      if (d1 === null) return null;

      return {
        tt,
        ttLabel: formatTTLabel(tt),
        dateLabel: new Date(r.createdAtIso).toLocaleDateString(),
        delta: d1,
        ...(d2 !== null ? { delta2: d2 } : {}),
      } as ChartPoint;
    })
    .filter(Boolean) as ChartPoint[];

  const n = base.length;
  if (n < 2) return base;

  // Trend for primary: regression over TT (not index)
  {
    const xs = base.map((p) => p.tt);
    const ys = base.map((p) => p.delta);
    const { slope, intercept } = linearRegression(xs, ys);
    for (let i = 0; i < base.length; i++) {
      base[i].trend = round1(slope * base[i].tt + intercept);
    }
  }

  // Trend for secondary (only if present and enough data)
  if (engineId2) {
    const xs2: number[] = [];
    const ys2: number[] = [];
    base.forEach((p) => {
      if (typeof p.delta2 === "number") {
        xs2.push(p.tt);
        ys2.push(p.delta2);
      }
    });

    if (xs2.length >= 2) {
      const { slope, intercept } = linearRegression(xs2, ys2);
      for (let i = 0; i < base.length; i++) {
        if (typeof base[i].delta2 === "number") {
          base[i].trend2 = round1(slope * base[i].tt + intercept);
        }
      }
    }
  }

  return base;
}

export default function TrendChart({
  records,
  engineId,
}: {
  records: PowerCheckRecord[];
  engineId?: string; // optional; defaults to first engine found
}) {
  const engineOptions = getEngineOptions(records);

  const primary = engineOptions.find((e) => e.engineId === engineId) ?? engineOptions[0];
  const secondary = engineOptions.find((e) => e.engineId !== primary.engineId);

  const data = toChartData(records, primary.engineId, secondary?.engineId);
  const isMulti = Boolean(secondary);

  return (
    <div className="h-72 w-full">
      <ResponsiveContainer>
        <LineChart data={data} margin={{ top: 10, right: 20, bottom: 10, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" />

          {/* X axis is now TT */}
          <XAxis
            dataKey="tt"
            type="number"
            domain={["dataMin", "dataMax"]}
            tickFormatter={(v) => formatTTLabel(Number(v))}
            label={{ value: "TT (hrs)", position: "insideBottom", offset: -5 }}
          />

          <YAxis />
          <Tooltip
            labelFormatter={(label) => `TT: ${formatTTLabel(Number(label))} hrs`}
            formatter={(value: any, name: any) => [value, name]}
            contentStyle={{}}
          />
          <Legend />

          <Line type="monotone" dataKey="delta" name={`${primary.engineLabel} Delta (%)`} dot={false} stroke="#008cff" />
          <Line
            type="monotone"
            dataKey="trend"
            name={`${primary.engineLabel} Trend`}
            dot={false}
            stroke="#007d9c"
            strokeDasharray="6 4"
          />

          {isMulti && (
            <>
              <Line
                type="monotone"
                dataKey="delta2"
                name={`${secondary!.engineLabel} Delta (%)`}
                dot={false}
                stroke="#7a0000"
              />
              <Line
                type="monotone"
                dataKey="trend2"
                name={`${secondary!.engineLabel} Trend`}
                dot={false}
                stroke="#ff0000"
                strokeDasharray="6 4"
              />
            </>
          )}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
