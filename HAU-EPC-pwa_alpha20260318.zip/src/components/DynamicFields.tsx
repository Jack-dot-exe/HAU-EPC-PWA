import { useEffect, useState } from "react";
import type { FieldDef, PowerCheckValues } from "../domain/models";
import { decimalToHHMM } from "../calculations/utils/time";

// Parse "HH:MM" -> decimal hours
// Accepts digits-only and decimal too.
function tryParseTTH(raw: string): number | undefined {
  const s = raw.trim();
  if (!s) return undefined;

  // Full HH:MM
  const m = s.match(/^(\d+):([0-5]\d)$/);
  if (m) {
    const hours = Number(m[1]);
    const minutes = Number(m[2]);
    const dec = hours + minutes / 60;
    return Number.isFinite(dec) ? dec : undefined;
  }

  // Pure hours (e.g. "1234" => 1234.0)
  if (/^\d+$/.test(s)) {
    const hours = Number(s);
    return Number.isFinite(hours) ? hours : undefined;
  }

  // Decimal hours (e.g. "1234.5" or "1234,5")
  if (/^\d+[.,]\d+$/.test(s)) {
    const num = parseFloat(s.replace(",", "."));
    return Number.isFinite(num) ? num : undefined;
  }

  return undefined;
}

// Keep only characters we allow in the input (digits, ":", ".", ",")
function sanitizeTTHInput(raw: string): string {
  return raw.replace(/[^\d:.,]/g, "");
}

export default function DynamicFields(props: {
  fields: FieldDef[];
  values: PowerCheckValues;
  setValue: (key: FieldDef["key"], value: number | undefined) => void;
}) {
  const externalTTH = props.values["TTH"];
  const [tthText, setTthText] = useState<string>("");

  // Sync from store -> text when store changes (load/reset)
  useEffect(() => {
    setTthText(externalTTH === undefined ? "" : decimalToHHMM(externalTTH));
  }, [externalTTH]);

  return (
    <div className="grid gap-3 md:grid-cols-3">
      {props.fields.map((f) => {
        const v = props.values[f.key];
        const isTTH = f.key === "TTH";

        return (
          <div key={f.key} className="flex flex-col gap-1">
            <label htmlFor={f.key} className="label-text label">
              {f.label}
              {f.unit && ` (${f.unit})`}
              {f.required && <span className="ml-1 text-red-500">*</span>}
            </label>

            {isTTH ? (
              <input
                id={f.key}
                type="text"
                className="input input-bordered w-full"
                inputMode="text"
                placeholder="HH:MM (e.g. 12345:30)"
                value={tthText}
                onChange={(e) => {
                  setTthText(sanitizeTTHInput(e.target.value));
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    const parsed = tryParseTTH(tthText);
                    props.setValue("TTH", parsed);
                    if (parsed !== undefined) setTthText(decimalToHHMM(parsed));
                  }
                }}
                onBlur={() => {
                  const parsed = tryParseTTH(tthText);
                  props.setValue("TTH", parsed);
                  if (parsed !== undefined) setTthText(decimalToHHMM(parsed));
                }}
              />
            ) : (
              <input
                id={f.key}
                type="number"
                className="input input-bordered w-full"
                inputMode="decimal"
                step={f.step ?? "any"}
                {...(f.min !== undefined ? { min: f.min } : {})}
                {...(f.max !== undefined ? { max: f.max } : {})}
                value={v ?? ""}
                onChange={(e) => {
                  const raw = e.target.value;

                  if (!raw) {
                    props.setValue(f.key, undefined);
                    return;
                  }

                  const normalized = raw.replace(",", ".");
                  const num = parseFloat(normalized);

                  props.setValue(f.key, Number.isFinite(num) ? num : undefined);
                }}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
