import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "./authStore";
import { useUsers } from "./usersStore";
import ThemeToggle from "../components/ThemeToggle";
import epclogo from "../assets/epclogo.svg";
import haulogo from "../assets/HAU-logo-schwarz.svg";
import htlogo from "../assets/HT-logo-schwarz.svg";

function navClass({ isActive }: { isActive: boolean }) {
  return isActive ? "btn btn-ghost btn-sm font-semibold" : "btn btn-ghost btn-sm";
}


export function AppShell() {

  //for logout
  const navigate = useNavigate();
  const { logout } = useAuth(); 
  const { currentUser } = useUsers();
  const isAdmin = currentUser?.role === "admin";

  return (
    <div className="min-h-screen bg-base-200 flex flex-col">
      <div className="navbar bg-base-100 shadow-sm p-4 mx-auto">
        <div className="navbar-start">
          <div className="dropdown">
            <div tabIndex={0} role="button" className="btn btn-ghost lg:hidden">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h8m-8 6h16" /> </svg>
            </div>
            <ul tabIndex={-1} className="menu menu-sm dropdown-content bg-base-300 rounded-box z-1 mt-3 w-52 p-2 shadow-lg">
              <li><NavLink to="/" className={navClass} end>New Check</NavLink></li>
              <li><NavLink to="/history" className={navClass}>History</NavLink></li>
              {isAdmin && <li><NavLink to="/admin" className={navClass}>Admin</NavLink></li>}
            </ul>
          </div>
          <Link to="/">  
            <img src={epclogo} className="min-w-32 mx-6"/>
          </Link>
        </div>
        <div className="navbar-center hidden lg:flex">
          <ul className="menu menu-horizontal px-1">
            <li><NavLink to="/" className={navClass} end>New Check</NavLink></li>
            <li><NavLink to="/history" className={navClass}>History</NavLink></li>
            {isAdmin && <li><NavLink to="/admin" className={navClass}>Admin</NavLink></li>}
          </ul>
        </div>
        <div className="navbar-end gap-3">
          <ThemeToggle />
          <button className="btn btn-ghost btn-circle">
            <div className="indicator">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /> </svg>
              <span className="badge badge-xs badge-primary indicator-item"></span>
            </div>
          </button>        
          {/* User Dropdown */}
          <div className="dropdown dropdown-end">
            <div tabIndex={0} role="button" className="btn btn-ghost btn-circle avatar">
              <div className="w-10 rounded-full shadow-md">
                <img
                  alt="Tailwind CSS Navbar component"
                  src="https://img.daisyui.com/images/stock/photo-1534528741775-53994a69daeb.webp" />
              </div>
            </div>
            <ul
              tabIndex={-1}
              className="menu menu-sm dropdown-content bg-base-100 rounded-box z-1 mt-3 w-52 p-2 shadow">
              <li>
                <a className="justify-between">
                  Profile
                  <span className="badge badge-warning">dummy</span>
                </a>
              </li>
              <li><a className="justify-between">
                Settings
                <span className="badge badge-warning">dummy</span>
                </a>
                </li>
              <li>
                <button
                  type="button"
                  className="font-semibold w-full text-left"
                  onClick={() => {
                    logout();
                    navigate("/login", { replace: true });
                  }}
                >
                  Logout
                </button>              
              </li>
            </ul>
          </div>
        </div>
      </div>
      <main className="mx-auto max-w-6xl p-4 flex-1">
        <Outlet />
      </main>

      <footer className="footer sm:footer-horizontal footer-center bg-base-300 text-base-content p-4">
        <aside>
          <label className="swap swap-flip ">
            {/* this hidden checkbox controls the state */}
            <input type="checkbox" />
            <div className="swap-on ">
              <img src={htlogo} className="max-h-12" />
            </div>
            <div className="swap-off">
              <img src={haulogo} className="max-h-15" />
            </div>
          </label>


          
          <p>Copyright © {new Date().getFullYear()} - All right reserved by Heli Austria GmbH</p>

        </aside>
      </footer>


    </div>
  );
}


