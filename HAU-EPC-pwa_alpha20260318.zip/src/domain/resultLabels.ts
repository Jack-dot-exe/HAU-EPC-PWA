// src/domain/resultLabels.ts
import type { AircraftProfile } from "../domain/models";

export type ResultLabels = {
  expected: string;
  actual: string;
  delta: string;
  unitSuffix: string;
};

export const DEFAULT_RESULT_LABELS: ResultLabels = {
  expected: "Expected",
  actual: "Actual",
  delta: "Delta",
  unitSuffix: "%",
};

export const RESULT_LABELS_BY_CALC_ID: Partial<Record<AircraftProfile["calculationId"], ResultLabels>> = {
  ec135_arrius_2b1_n1: {
    expected: "Max. Chart N1",
    actual: "Actual N1",
    delta: "Delta N1",
    unitSuffix: "%",
  },
  bell412_pw_pt6t3b_itt: {
    expected: "Max. Chart ITT",
    actual: "Actual ITT",
    delta: "Delta ITT",
    unitSuffix: " deg C",
  },
  generic_placeholder: DEFAULT_RESULT_LABELS,
};

export function getResultLabels(calculationId?: AircraftProfile["calculationId"]): ResultLabels {
  return (calculationId && RESULT_LABELS_BY_CALC_ID[calculationId]) ?? DEFAULT_RESULT_LABELS;
}
