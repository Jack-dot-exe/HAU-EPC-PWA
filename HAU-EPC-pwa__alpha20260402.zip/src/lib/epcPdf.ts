import { jsPDF } from "jspdf";
import epclogo from "../assets/epclogo.png";
import haulogo from "../assets/HAU-logo-schwarz.png";
import { CALC_VERSIONS } from "../calculations";
import type {
  AircraftProfile,
  CheckType,
  EngineDef,
  FieldDef,
  InputFieldKey,
  PowerCheckRecord,
  PowerCheckResult,
  PowerCheckValues,
  Registration,
} from "../domain/models";
import { getDisplayMetrics } from "../domain/resultMetrics";
import { formatFieldValue, formatMetricValue, getFieldUnitId, getUnitLabel } from "../domain/units";

// Shape of the data needed to generate the PDF report.
type EpcPdfPayload = {
  registration: Registration;
  profile: AircraftProfile;
  checkType: CheckType;
  engines: EngineDef[];
  envFields: FieldDef[];
  engineFields: FieldDef[];
  envValues: PowerCheckValues;
  engineValues: PowerCheckValues[];
  computedResults: PowerCheckResult[];
  exportedAt: Date;
  checkPerformedAt: Date;
  calculationVersion: string;
};

// Static footer labels.
// These can later be replaced with real app/profile version values.
const APP_VERSION_PLACEHOLDER = "App Version: TBD";

// Input fields treated as "environment" values instead of engine-specific values.
const ENV_KEYS: InputFieldKey[] = ["TTH", "OAT", "PA"];

// Formats a field value for PDF display.
// - returns "-" when missing
// - converts TTH decimal values into HH:MM
// - appends units where available
function formatValue(field: FieldDef, value: number | undefined): string {
  return formatFieldValue(field, value);
}

// Builds a user-friendly field label.
// Example: "OAT (�C)" instead of just "OAT"
function fieldLabel(field: FieldDef): string {
  const unit = getUnitLabel(getFieldUnitId(field));
  return unit ? `${field.label} (${unit})` : field.label;
}

// Normalizes engine data from saved records.
//
// Some saved records may have:
// - a multi-engine structure: record.engines[]
// - a legacy single-engine structure: record.values / record.result
//
// This helper makes both cases look the same to the PDF generator.
function getEnginesFromRecord(
  record: PowerCheckRecord,
): Array<{
  engineId: string;
  engineLabel: string;
  values: PowerCheckValues;
  result?: PowerCheckResult;
}> {
  const anyRec = record as PowerCheckRecord & {
    values?: PowerCheckValues;
    result?: PowerCheckResult;
  };

  // Preferred path: multi-engine record format
  if (Array.isArray(record.engines) && record.engines.length > 0) {
    return record.engines.map((engine, index) => ({
      engineId: String(engine.engineId ?? index + 1),
      engineLabel: String(engine.engineLabel ?? `ENG ${index + 1}`),
      values: engine.values ?? {},
      result: engine.result,
    }));
  }

  // Backward-compatible fallback: single-engine record format
  return [
    {
      engineId: "1",
      engineLabel: "ENG 1",
      values: anyRec.values ?? {},
      result: anyRec.result,
    },
  ];
}

// Creates the PDF payload from a saved power-check record.
//
// This:
// - separates environment fields from engine-specific fields
// - normalizes engine rows
// - extracts computed results
// - attaches metadata like exported date and calculation version
export function createEpcPdfPayloadFromRecord(
  record: PowerCheckRecord,
  registration: Registration,
  profile: AircraftProfile,
): EpcPdfPayload {
  const fields = profile.inputSchema[record.checkType] ?? [];

  // Split all input fields into environment vs engine-specific groups.
  const envFields = fields.filter((field) => ENV_KEYS.includes(field.key));
  const engineFields = fields.filter((field) => !ENV_KEYS.includes(field.key));

  // Normalize engine data regardless of the saved record shape.
  const engineRows = getEnginesFromRecord(record);

  // Collect valid computed results from engine rows.
  const computedResults = engineRows
    .map((engine) => engine.result)
    .filter(Boolean) as PowerCheckResult[];

  if (computedResults.length === 0) {
    throw new Error("This saved check does not contain exportable results.");
  }

  return {
    registration,
    profile,
    checkType: record.checkType,

    // Convert normalized engine rows into the EngineDef shape used in the payload.
    engines: engineRows.map((engine) => ({
      id: engine.engineId,
      label: engine.engineLabel,
    })) as EngineDef[],

    envFields,
    engineFields,

    // Environment values are taken from the first engine row because they are shared.
    envValues: (engineRows[0]?.values ?? {}) as PowerCheckValues,

    // Engine-specific values remain as one entry per engine.
    engineValues: engineRows.map((engine) => engine.values ?? {}),

    computedResults,

    // Use the pdf download date as the export date shown on the report.
    // Use the checkPerf. Date in the General Header section.
    exportedAt: new Date(),
    checkPerformedAt: new Date(record.createdAtIso),

    // Use the explicit record version first, otherwise fall back to the current calculation map.
    calculationVersion:
      record.calculationVersion ??
      CALC_VERSIONS[profile.calculationId] ??
      "Version UKNOWN",
  };
}

// Adds a footer to every page in the generated PDF.
//
// Footer includes:
// - check/ !!export!! date !!TO-DO!!
// - app version placeholder
// - profile/model + calculation version
function addFooter(
  doc: jsPDF,
  exportedAt: Date,
  calculationVersion: string,
  payload: EpcPdfPayload,
): void {
  const pageCount = doc.getNumberOfPages();
  const footerDate = exportedAt.toLocaleString();

  for (let page = 1; page <= pageCount; page += 1) {
    doc.setPage(page);

    const width = doc.internal.pageSize.getWidth();
    const height = doc.internal.pageSize.getHeight();

    // Draw a divider line above the footer.
    doc.setDrawColor(220, 220, 220);
    doc.line(14, height - 22, width - 14, height - 22);

    doc.setFontSize(9);
    doc.setTextColor(110, 110, 110);

    // Left side: check date
    // *TO-DO* Set Print Date -> move this higher to Check Details
    doc.text(`Print Date: ${footerDate}`, 14, height - 11);

    // Upper-right footer line: app version
    doc.text(APP_VERSION_PLACEHOLDER, width - 14, height - 16, {
      align: "right",
    });

    doc.addImage(haulogo, "PNG", width / 2 - 11.5, height - 18, 23, 11);

    // Lower-right footer line: aircraft/profile version info
    doc.text(
      `Based on: ${payload.profile.calculationId} - ${calculationVersion}`,
      width - 14,
      height - 11,
      { align: "right" },
    );
  }
}

function getEpcPdfFilename(payload: EpcPdfPayload): string {
  const datePart = payload.checkPerformedAt
    .toISOString()
    .slice(0, 10)
    .replace(/-/g, "");

  return `EPC${datePart}${payload.registration.tailNumber}.pdf`;
}

// Main PDF generator.
//
// This function:
// - creates the PDF document
// - lays out the report sections
// - handles pagination
// - writes input data and result metrics
// - adds the footer
export function buildEpcPdfDocument(payload: EpcPdfPayload): jsPDF {
  const doc = new jsPDF({ unit: "mm", format: "a4" });

  // Basic page geometry
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginX = 14;
  const contentWidth = pageWidth - marginX * 2;
  const bottomGuard = 24;

  // Vertical cursor used for manual layout flow.
  let cursorY = 18;

  // Adds a new page if there is not enough vertical room left.
  const ensureSpace = (needed = 10) => {
    if (cursorY + needed <= pageHeight - bottomGuard) return;
    doc.addPage();
    cursorY = 18;
  };

  // Draws a section heading with consistent styling.
  const sectionTitle = (title: string) => {
    ensureSpace(12);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(13);
    doc.setTextColor(25, 25, 25);
    doc.text(title, marginX, cursorY);
    cursorY += 6;
  };

  // Draws a single label/value row.
  //
  // Example:
  // Registration: OE-XYZ
  const bodyLine = (label: string, value: string, indent = 0) => {
    ensureSpace(7);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(35, 35, 35);
    doc.text(`${label}:`, marginX + indent, cursorY);

    doc.setFont("helvetica", "normal");
    doc.text(value, marginX + indent + 45, cursorY);

    cursorY += 5.5;
  };

  // Draws a wrapped paragraph of text.
  const bodyParagraph = (text: string) => {
    const lines = doc.splitTextToSize(text, contentWidth);
    ensureSpace(lines.length * 5 + 2);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(55, 55, 55);
    doc.text(lines, marginX, cursorY);

    cursorY += lines.length * 5;
  };

  // Try to load and render the EPC logo at the top-left of the report.
  doc.addImage(epclogo, "PNG", marginX, cursorY - 4, 33, 14);

  // Report header
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.setTextColor(25, 25, 25);
  doc.text("Engine Power Check Report", marginX + 40, cursorY + 4);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(90, 90, 90);
  doc.text("Generated from calculation results", marginX + 40, cursorY + 10);

  cursorY += 22;

  // Section: basic metadata about the report/check
  sectionTitle("Check Details");
  bodyLine("Registration", payload.registration.tailNumber);
  bodyLine(
    "Aircraft",
    `${payload.profile.modelName} (${payload.profile.engine})`,
  );
  bodyLine("EPC Type:", payload.checkType);
  bodyLine("EPC Perf.:", payload.checkPerformedAt.toLocaleString());
  cursorY += 3;

  // Section: entered input values
  sectionTitle("Input Values");

  // Environment/General values (shared / non-engine-specific fields)
  if (payload.envFields.length > 0) {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text("General", marginX, cursorY);
    cursorY += 5;

    for (const field of payload.envFields) {
      bodyLine(
        fieldLabel(field),
        formatValue(field, payload.envValues[field.key]),
        4,
      );
    }

    cursorY += 2;
  }

  // Per-engine input values
  for (const [index, engine] of payload.engines.entries()) {
    ensureSpace(12);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(25, 25, 25);
    doc.text(engine.label, marginX, cursorY);
    cursorY += 5;

    if (payload.engineFields.length === 0) {
      bodyParagraph("This check type has no engine-specific input fields.");
      continue;
    }

    for (const field of payload.engineFields) {
      bodyLine(
        fieldLabel(field),
        formatValue(field, payload.engineValues[index]?.[field.key]),
        4,
      );
    }

    cursorY += 8;
  }

  // Section: calculation results
  sectionTitle("Results");

  // Overall result passes only if every engine result passes.
  const overallPass = payload.computedResults.every((result) => result.pass);
  bodyLine("Overall Result", overallPass ? "PASS" : "FAIL");
  cursorY += 2;

  // Per-engine computed metrics
  for (const [index, engine] of payload.engines.entries()) {
    const result = payload.computedResults[index];
    if (!result) continue;

    // Convert raw result object into display-friendly metric rows.
    const metrics = getDisplayMetrics(result, payload.profile.calculationId);

    ensureSpace(Math.max(18, metrics.length * 18 + 10));
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(25, 25, 25);
    doc.text(`${engine.label} - ${result.pass ? "PASS" : "FAIL"}`, marginX, cursorY);
    cursorY += 6;

    // Draw one card-like block per metric.
    for (const metric of metrics) {
      ensureSpace(16);

      // Outer box
      doc.setDrawColor(225, 225, 225);
      doc.roundedRect(marginX, cursorY - 3, contentWidth, 16, 2, 2);

      // Metric title
      doc.setFont("helvetica", "bold");
      doc.setFontSize(10);
      doc.text(metric.title, marginX + 3, cursorY + 1);

      // Metric values
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9);
      doc.text(
        `${metric.expectedLabel}: ${formatMetricValue(metric, metric.expected)}`,
        marginX + 3,
        cursorY + 6,
      );
      doc.text(
        `${metric.actualLabel}: ${formatMetricValue(metric, metric.actual)}`,
        marginX + 3,
        cursorY + 10,
      );
      doc.text(
        `${metric.deltaLabel}: ${formatMetricValue(metric, metric.delta)}`,
        marginX + 80,
        cursorY + 6,
      );
      doc.text(
        `Status: ${metric.pass ? "PASS" : "FAIL"}`,
        marginX + 80,
        cursorY + 10,
      );

      cursorY += 20;
    }
  }

  // Apply footer to all pages after the full document has been built.
  addFooter(doc, payload.exportedAt, payload.calculationVersion, payload);

  return doc;
}

export async function createEpcResultPdfBlob(
  payload: EpcPdfPayload,
): Promise<Blob> {
  const doc = buildEpcPdfDocument(payload);
  return doc.output("blob");
}

export async function downloadEpcResultPdf(
  payload: EpcPdfPayload,
): Promise<void> {
  const doc = buildEpcPdfDocument(payload);
  doc.save(getEpcPdfFilename(payload));
}

// Convenience wrapper for generating a PDF directly from a saved record.
export async function downloadSavedCheckPdf(
  record: PowerCheckRecord,
  registration: Registration,
  profile: AircraftProfile,
): Promise<void> {
  await downloadEpcResultPdf(
    createEpcPdfPayloadFromRecord(record, registration, profile),
  );
}

export async function createSavedCheckPdfBlob(
  record: PowerCheckRecord,
  registration: Registration,
  profile: AircraftProfile,
): Promise<Blob> {
  return createEpcResultPdfBlob(
    createEpcPdfPayloadFromRecord(record, registration, profile),
  );
}



