// src/app/profileStore.tsx
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { AircraftProfile, EngineDef, FieldDef, InputFieldKey, PowerCheckLimits } from "../domain/models";
import { getFieldUnitId } from "../domain/units";
import {
  deleteProfileCloud,
  fetchProfilesCloud,
  replaceProfilesCloud,
  upsertProfileCloud,
} from "../lib/cloudDb";

type ProfilesContextValue = {
  profiles: AircraftProfile[];
  addProfile: (p: AircraftProfile) => void;
  updateProfile: (id: string, patch: Partial<AircraftProfile>) => void;
  removeProfile: (id: string) => void;
  resetProfiles: () => void;
};

const ProfilesContext = createContext<ProfilesContextValue | null>(null);
const STORAGE_KEY_V2 = "engine-power:profiles:v2";

const BELL412_IN_FLIGHT_FIELDS: FieldDef[] = [
  { key: "TTH", label: "Total Time", unitId: "hhmm", required: false },
  { key: "OAT", label: "OAT", unitId: "celsius", required: true },
  { key: "PA", label: "PA", unitId: "feet", required: true },
  { key: "TRQ", label: "TRQ", unitId: "percent", required: true },
  { key: "ITT", label: "Actual ITT", unitId: "celsius", required: true },
  { key: "N1", label: "Actual N1", unitId: "percent", required: true },
];

function safeParse(json: string | null): AircraftProfile[] | null {
  if (!json) return null;
  try {
    const data = JSON.parse(json);
    return Array.isArray(data) ? (data as AircraftProfile[]) : null;
  } catch {
    return null;
  }
}

function normalizeField(field: FieldDef): FieldDef {
  const unitId = getFieldUnitId(field);
  return {
    ...field,
    ...(unitId ? { unitId } : {}),
  };
}

function normalizeInputSchema(inputSchema: AircraftProfile["inputSchema"]): AircraftProfile["inputSchema"] {
  return Object.fromEntries(
    Object.entries(inputSchema).map(([checkType, fields]) => [checkType, fields?.map(normalizeField)]),
  ) as AircraftProfile["inputSchema"];
}

function defaultEngines(engineCount: number): EngineDef[] {
  return Array.from({ length: engineCount }, (_, i) => ({
    id: String(i + 1),
    label: `ENG ${i + 1}`,
  }));
}

function normalizeBell412InputSchema(profile: AircraftProfile): AircraftProfile["inputSchema"] {
  const normalizedInputSchema = normalizeInputSchema(profile.inputSchema);
  if (profile.calculationId !== "bell412_pw_pt6t3b_itt") return normalizedInputSchema;

  const inFlight = normalizedInputSchema["In-Flight"] ?? [];
  const byKey = new Map<InputFieldKey, FieldDef>(inFlight.map((field) => [field.key, field]));

  for (const field of BELL412_IN_FLIGHT_FIELDS) {
    byKey.set(field.key, {
      ...field,
      ...(byKey.get(field.key) ?? {}),
    });
  }

  return {
    ...normalizedInputSchema,
    "In-Flight": BELL412_IN_FLIGHT_FIELDS.map((field) => byKey.get(field.key) ?? field),
  };
}

function normalizeLimits(profile: AircraftProfile): PowerCheckLimits {
  const limits = profile.limits ?? { deltaPercentPass: 0 };
  if (profile.calculationId !== "bell412_pw_pt6t3b_itt") return limits;

  return {
    ...limits,
    bell412IttDeltaPass: limits.bell412IttDeltaPass ?? limits.deltaPercentPass,
    bell412N1DeltaPass: limits.bell412N1DeltaPass ?? limits.deltaPercentPass,
  };
}

function normalizeEngines(
  engines: EngineDef[] | undefined,
  engineCount: number
): EngineDef[] | undefined {
  const count = Math.max(1, Math.floor(engineCount || 1));

  if (count === 1) {
    return engines && engines.length > 0 ? engines.slice(0, 1) : undefined;
  }

  if (!engines || engines.length === 0) {
    return defaultEngines(count);
  }

  const trimmed = engines.slice(0, count);
  if (trimmed.length < count) {
    const existingIds = new Set(trimmed.map((e) => e.id));
    for (let i = trimmed.length; i < count; i++) {
      const id = String(i + 1);
      trimmed.push({
        id: existingIds.has(id) ? `E${id}` : id,
        label: `ENG ${i + 1}`,
      });
    }
  }

  const seen = new Set<string>();
  const uniqued = trimmed.map((e, idx) => {
    let id = (e.id ?? "").trim() || String(idx + 1);
    if (seen.has(id)) id = `${id}_${idx + 1}`;
    seen.add(id);
    return { ...e, id, label: (e.label ?? "").trim() || `ENG ${idx + 1}` };
  });

  return uniqued;
}

function normalizeProfile(p: AircraftProfile): AircraftProfile {
  const derivedCount =
    (typeof p.engineCount === "number" && isFinite(p.engineCount) ? p.engineCount : undefined) ??
    (p.engines?.length ? p.engines.length : undefined) ??
    1;

  const engineCount = Math.max(1, Math.floor(derivedCount));
  const engines = normalizeEngines(p.engines, engineCount);

  return {
    ...p,
    engineCount,
    engines,
    limits: normalizeLimits(p),
    inputSchema: normalizeBell412InputSchema(p),
  };
}

function normalizeProfiles(list: AircraftProfile[]): AircraftProfile[] {
  return list.map(normalizeProfile);
}

export function ProfilesProvider({ children }: { children: React.ReactNode }) {
  const [profiles, setProfiles] = useState<AircraftProfile[]>([]);

  useEffect(() => {
    let active = true;
    const localV2 = safeParse(localStorage.getItem(STORAGE_KEY_V2));
    const localProfiles = normalizeProfiles(localV2 ?? []);

    fetchProfilesCloud()
      .then(async (remote) => {
        if (!active) return;

        if (remote && remote.length > 0) {
          setProfiles(normalizeProfiles(remote));
        } else if (localProfiles.length > 0) {
          setProfiles(localProfiles);
          await replaceProfilesCloud(localProfiles);
        } else {
          setProfiles([]);
        }

        localStorage.removeItem(STORAGE_KEY_V2);
      })
      .catch((e) => console.error("Failed to load profiles from Supabase:", e));

    return () => {
      active = false;
    };
  }, []);

  const value = useMemo<ProfilesContextValue>(() => {
    return {
      profiles,

      addProfile: (p) => {
        const normalized = normalizeProfile(p);
        setProfiles((prev) => [normalized, ...prev]);
        upsertProfileCloud(normalized).catch((e) =>
          console.error("Failed to upsert profile in Supabase:", e)
        );
      },

      updateProfile: (id, patch) =>
        setProfiles((prev) =>
          prev.map((p) => {
            if (p.id !== id) return p;
            const normalized = normalizeProfile({ ...p, ...patch });
            upsertProfileCloud(normalized).catch((e) =>
              console.error("Failed to update profile in Supabase:", e)
            );
            return normalized;
          })
        ),

      removeProfile: (id) => {
        setProfiles((prev) => prev.filter((p) => p.id !== id));
        deleteProfileCloud(id).catch((e) =>
          console.error("Failed to delete profile in Supabase:", e)
        );
      },

      resetProfiles: () => {
        setProfiles([]);
        replaceProfilesCloud([]).catch((e) =>
          console.error("Failed to reset profiles in Supabase:", e)
        );
        localStorage.removeItem(STORAGE_KEY_V2);
      },
    };
  }, [profiles]);

  return <ProfilesContext.Provider value={value}>{children}</ProfilesContext.Provider>;
}

export function useProfiles() {
  const ctx = useContext(ProfilesContext);
  if (!ctx) throw new Error("useProfiles must be used inside ProfilesProvider");
  return ctx;
}
