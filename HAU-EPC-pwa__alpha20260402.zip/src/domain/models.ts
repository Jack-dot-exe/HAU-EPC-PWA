// =======================
// Check modes


// =======================
import type { UnitId } from "./units";

export type CheckType = "Ground" | "Hover" | "In-Flight";

// =======================
// Allowed input fields
// =======================
export type InputFieldKey =
  | "TTH" // Aircraft Total Time at time of EPC (hrs)
  | "OAT"  // Outside Air Temperature (°C)
  | "PA"   // Pressure Altitude (ft)
  | "TRQ"  // Torque (%)
  | "TOT"  // Turbine Outlet Temperature (°C)
  | "ITT"  // Inter-Turbine Temperature (°C)
  | "N1";  // N1 (%)

// =======================
// Field definition (UI + validation metadata)
// =======================
export interface FieldDef {
  key: InputFieldKey;
  label: string;
  unitId?: UnitId;
  unit?: string;
  required?: boolean;
  step?: number;
  min?: number;
  max?: number;
}

// =======================
// Dynamic values entered by the user
// =======================
export type PowerCheckValues = Partial<Record<InputFieldKey, number>>;

// =======================
// Multi-engine support
// =======================
// Engine IDs are intentionally strings so we can support:
// - simple numbering ("1", "2")
// - descriptive ids ("LH", "RH")
// - future special cases ("APU", "CENTER")
export type EngineId = string;

export interface EngineDef {
  id: EngineId;
  label: string; // e.g. "ENG 1", "ENG 2"
}

export interface EnginePowerCheck {
  engineId: EngineId;
  // Optional because UI can render a label even if profile doesn't define one.
  // If present, prefer this over profile label (useful for per-registration overrides).
  engineLabel?: string;
  values: PowerCheckValues;
  result: PowerCheckResult;
}

export interface PowerCheckOverallResult {
  // Overall status (e.g. any engine FAIL => FAIL). Cross-engine flags can still be WARN.
  pass: boolean;
  // Optional cross-engine comparisons (deltas, mismatch warnings, etc.).
  // Kept generic so calculations can evolve without schema churn.
  flags?: Array<{
    code: string;
    severity: "WARN" | "FAIL";
    message: string;
  }>;
}

// =======================
// Calculation mapping
// =======================
export type CalculationId =
  | "ec135_arrius_2b1_n1"
  | "bell412_pw_pt6t3b_itt"
  | "generic_placeholder";

export interface PowerCheckLimits {
  deltaPercentPass: number;
  bell412IttDeltaPass?: number;
  bell412N1DeltaPass?: number;
}

// =======================
// Aircraft profile
// =======================
export interface AircraftProfile {
  id: string;
  modelName: string;
  // Prefer engines[] for multi-engine aircraft.
  engine: string;

  // Number of engines for this aircraft profile.
  // Use 1 for single engine aircraft.
  engineCount?: number;

  // Optional per-engine definitions (labels, ids). If omitted, the app should
  // generate default engines based on engineCount ("1".."N").
  engines?: EngineDef[];

  // Which checks are supported by this model
  checkTypes: CheckType[];

  // Pass/fail threshold; interpretation depends on calc.
  // For EC135 N1: this is N1 percentage points.
  limits: PowerCheckLimits;

  // Per-check visible inputs
  inputSchema: Partial<Record<CheckType, FieldDef[]>>;

  // Which calculation implementation to use
  calculationId: CalculationId;

  powerCheckDescription?: string;
}

// =======================
// Registration
// =======================
export interface Registration {
  id: string;
  tailNumber: string;
  profileId: string;

  // Optional per-registration engine definitions.
  // Use this to override profile defaults (e.g., custom labels "LH"/"RH",
  // swapped numbering after maintenance, special engine ids, etc.).
  // If omitted, the app should fall back to AircraftProfile.engineCount/engines.
  engines?: EngineDef[];
}

// =======================
// Users / roles
// =======================
export type Role = "admin" | "editor" | "viewer";

export interface User {
  id: string;
  email: string;
  role: Role;
  isActive: boolean;
  // local-auth fields (PBKDF2)
  passwordSalt?: string;     // base64
  passwordHash?: string;     // base64
  passwordIterations?: number;

}

// =======================
// Power check result (generic UI fields)
// expectedPct/actualPct/deltaPct remain the primary metric for legacy UI/trends.
// metrics[] can hold multiple named result groups for calculations like Bell 412.
// =======================
export interface PowerCheckMetricResult {
  id: string;
  title: string;
  expectedLabel: string;
  actualLabel: string;
  deltaLabel: string;
  unitId?: UnitId;
  unitSuffix?: string;
  expected: number;
  actual: number;
  delta: number;
  pass: boolean;
  preferredForTrend?: boolean;
}

export interface PowerCheckResult {
  expectedPct: number;
  actualPct: number;
  deltaPct: number;
  pass: boolean;
  metrics?: PowerCheckMetricResult[];
}

// =======================
// Stored power check record (audit-safe)
// =======================
export interface PowerCheckRecord {
  id: string;
  createdAtIso: string;
  registrationId: string;
  checkType: CheckType;
  totalTimeHrs?: number;
  calculationVersion?: string;
  createdByUserId?: string;
  createdByUserEmail?: string;

  // ---- Schema versioning ----
  // v1: single-engine storage (values/result) // OBSOLETE !! //
  // v2: multi-engine storage (engines + optional overallResult)
  // If absent, treat as v1 (for backwards compatibility with existing storage).
  schemaVersion?: 1 | 2;

  // ---- v1 (legacy) ----
  // Kept optional so existing UI can keep compiling while we migrate screens.
  values?: PowerCheckValues;
  result?: PowerCheckResult;

  // ---- v2 (multi-engine) ----
  engines?: EnginePowerCheck[];
  overallResult?: PowerCheckOverallResult;
}
