import { decimalToHHMM } from "../calculations/utils/time";
import type { FieldDef, InputFieldKey, PowerCheckMetricResult } from "./models";

export type UnitId = "percent" | "celsius" | "feet" | "hhmm";

export const UNIT_LABELS: Record<UnitId, string> = {
  percent: "%",
  celsius: "°C",
  feet: "ft",
  hhmm: "HH:MM",
};

const LEGACY_UNIT_MAP: Record<string, UnitId> = {
  "%": "percent",
  ft: "feet",
  "HH:MM": "hhmm",
  "�C": "celsius",
  "°C": "celsius",
  "Â°C": "celsius",
};

const INPUT_FIELD_UNITS: Partial<Record<InputFieldKey, UnitId>> = {
  TTH: "hhmm",
  OAT: "celsius",
  PA: "feet",
  TRQ: "percent",
  TOT: "celsius",
  ITT: "celsius",
  N1: "percent",
};

export function getUnitLabel(unitId?: UnitId): string {
  return unitId ? UNIT_LABELS[unitId] : "";
}

export function normalizeLegacyUnit(unit?: string): UnitId | undefined {
  if (!unit) return undefined;
  return LEGACY_UNIT_MAP[unit.trim()];
}

export function getInputFieldUnitId(key: InputFieldKey): UnitId | undefined {
  return INPUT_FIELD_UNITS[key];
}

export function getFieldUnitId(field: Pick<FieldDef, "key" | "unitId"> & { unit?: string }): UnitId | undefined {
  return field.unitId ?? normalizeLegacyUnit(field.unit) ?? getInputFieldUnitId(field.key);
}

export function getMetricUnitId(
  metric: Pick<PowerCheckMetricResult, "unitId"> & { unitSuffix?: string },
): UnitId | undefined {
  return metric.unitId ?? normalizeLegacyUnit(metric.unitSuffix);
}

export function formatValueByUnit(value: number, unitId?: UnitId): string {
  if (unitId === "hhmm") return decimalToHHMM(value);
  const unit = getUnitLabel(unitId);
  return unit ? `${value} ${unit}` : String(value);
}

export function formatFieldValue(
  field: Pick<FieldDef, "key" | "unitId"> & { unit?: string },
  value: number | undefined,
): string {
  if (value === undefined || Number.isNaN(value)) return "-";
  return formatValueByUnit(value, getFieldUnitId(field));
}

export function formatMetricValue(
  metric: Pick<PowerCheckMetricResult, "unitId"> & { unitSuffix?: string },
  value: number,
): string {
  const unit = getUnitLabel(getMetricUnitId(metric));
  return unit ? `${value}${unit}` : String(value);
}
